<?php
/**
 * DiamondGhor API — shared bootstrap for every /api endpoint.
 *
 * Loads the config file from OUTSIDE the web root (dg-config.php, written by
 * /api/install/), connects to MySQL through PDO (prepared statements only),
 * hardens the PHP session, and provides every helper the endpoints share:
 * CSRF, rate limiting, login throttling, admin logs, Telegram notifications,
 * content/settings storage, row mappers and the pricing/spin rule engine.
 *
 * PHP 7.4+ compatible, no external dependencies.
 */

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Cache-Control: no-store, max-age=0');

// ------------------------------------------------------------------ output

function dg_json_out($status, $payload) {
    http_response_code((int) $status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function dg_fail($status, $error, $extra = array()) {
    $payload = array_merge(array('ok' => false, 'error' => $error), $extra);
    dg_json_out($status, $payload);
}

// ------------------------------------------------------------------ config

function dg_config_candidates() {
    $candidates = array();
    $env = getenv('DG_CONFIG');
    if ($env) {
        $candidates[] = $env;
    }
    $docroot = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '/') : '';
    if ($docroot) {
        $candidates[] = dirname($docroot) . '/dg-config.php';
    }
    $candidates[] = dirname(__DIR__, 2) . '/dg-config.php';
    // Last resort inside the web root (blocked from HTTP by api/.htaccess).
    $candidates[] = __DIR__ . '/config.php';
    return $candidates;
}

$dg_config_loaded = false;
foreach (dg_config_candidates() as $dg_config_path) {
    if ($dg_config_path && is_file($dg_config_path)) {
        require $dg_config_path;
        $dg_config_loaded = true;
        break;
    }
}
if (!defined('DG_DB_HOST')) {
    dg_json_out(503, array(
        'ok' => false,
        'code' => 'not_installed',
        'error' => 'DiamondGhor server is not installed yet. Open /api/install/ in your browser and finish the 2-minute setup.',
    ));
}
if (!defined('DG_DB_PREFIX')) {
    define('DG_DB_PREFIX', 'dg_');
}
if (!defined('DG_TIMEZONE')) {
    define('DG_TIMEZONE', 'Asia/Dhaka');
}
if (!defined('DG_SESSION_NAME')) {
    define('DG_SESSION_NAME', 'DGHSESS');
}
date_default_timezone_set(DG_TIMEZONE);

// ------------------------------------------------------------------ session

dg_session_start();

function dg_session_start() {
    static $started = false;
    if ($started) {
        return;
    }
    $started = true;
    $secure = dg_is_https();
    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params(array(
            'lifetime' => 0,
            'path' => '/',
            'domain' => '',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ));
    } else {
        session_set_cookie_params(0, '/; samesite=Lax' . ($secure ? '; secure' : ''), '', $secure, true);
    }
    session_name(DG_SESSION_NAME);
    @session_start();
}

function dg_is_https() {
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        return true;
    }
    if (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443) {
        return true;
    }
    if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') {
        return true;
    }
    return false;
}

function dg_client_ip() {
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $parts = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($parts[0]);
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        }
    }
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
}

// ------------------------------------------------------------------ database

function dg_db() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }
    $dsn = 'mysql:host=' . DG_DB_HOST . ';dbname=' . DG_DB_NAME . ';charset=utf8mb4';
    if (defined('DG_DB_PORT') && DG_DB_PORT) {
        $dsn = 'mysql:host=' . DG_DB_HOST . ';port=' . DG_DB_PORT . ';dbname=' . DG_DB_NAME . ';charset=utf8mb4';
    }
    try {
        $pdo = new PDO($dsn, DG_DB_USER, DG_DB_PASS, array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ));
    } catch (PDOException $e) {
        dg_fail(503, 'Database connection failed. Check dg-config.php credentials.');
    }
    return $pdo;
}

function dg_prefix() {
    return DG_DB_PREFIX;
}

// ------------------------------------------------------------------ requests

function dg_body() {
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $raw = file_get_contents('php://input');
    if (strlen($raw) > 2097152) {
        dg_fail(413, 'Request body too large.');
    }
    $data = json_decode($raw, true);
    $cache = is_array($data) ? $data : array();
    return $cache;
}

function dg_field($body, $key, $default = '') {
    if (!isset($body[$key])) {
        return $default;
    }
    if (is_string($body[$key])) {
        return trim($body[$key]);
    }
    return $body[$key];
}

function dg_site_base() {
    $scheme = dg_is_https() ? 'https' : 'http';
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    return $scheme . '://' . $host;
}

// ------------------------------------------------------------------ CSRF

function dg_csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(20));
    }
    return $_SESSION['csrf'];
}

// $allowInitial: login/register/google may arrive before the browser ever
// saw a token (fresh session = brand-new cookie, nothing to fixate).
// Everything else strictly requires the header.
function dg_check_csrf($body = array(), $allowInitial = false) {
    $expected = empty($_SESSION['csrf']) ? '' : $_SESSION['csrf'];
    $sent = isset($_SERVER['HTTP_X_DG_CSRF']) ? trim((string) $_SERVER['HTTP_X_DG_CSRF']) : '';
    if ($sent === '' && isset($body['csrf'])) {
        $sent = trim((string) $body['csrf']);
    }
    if ($expected === '' && $allowInitial) {
        return;
    }
    if ($expected === '' || $sent === '' || !hash_equals($expected, $sent)) {
        dg_fail(403, 'Session expired — reload the page and try again.');
    }
}

// ------------------------------------------------------------------ rate limiting

function dg_rate_limit($name, $max, $windowSeconds) {
    $pdo = dg_db();
    $windowStart = (int) (time() / max(5, (int) $windowSeconds)) * max(5, (int) $windowSeconds);
    $bucket = md5($name . '|' . dg_client_ip());
    $st = $pdo->prepare('INSERT INTO ' . dg_prefix() . 'rate_limits (bucket, window_start, hits) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE hits = IF(window_start = VALUES(window_start), hits + 1, 1), window_start = VALUES(window_start)');
    $st->execute(array($bucket, $windowStart));
    $st = $pdo->prepare('SELECT window_start, hits FROM ' . dg_prefix() . 'rate_limits WHERE bucket = ?');
    $st->execute(array($bucket));
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if ($row && (int) $row['window_start'] === $windowStart && (int) $row['hits'] > (int) $max) {
        dg_fail(429, 'Too many requests — ektu por abar try korun.');
    }
    if (random_int(1, 200) === 1) {
        try {
            $pdo->exec('DELETE FROM ' . dg_prefix() . 'rate_limits WHERE window_start < ' . (time() - 86400));
        } catch (Exception $e) {
            /* ignore */
        }
    }
}

// ------------------------------------------------------------------ login throttling

function dg_login_attempt_row($email) {
    $st = dg_db()->prepare('SELECT * FROM ' . dg_prefix() . 'login_attempts WHERE email = ?');
    $st->execute(array(strtolower($email)));
    $row = $st->fetch(PDO::FETCH_ASSOC);
    return $row ? $row : null;
}

function dg_login_locked($email) {
    $row = dg_login_attempt_row($email);
    if ($row && !empty($row['locked_until']) && strtotime($row['locked_until']) > time()) {
        return (int) (strtotime($row['locked_until']) - time());
    }
    return 0;
}

function dg_login_fail($email) {
    $pdo = dg_db();
    $st = $pdo->prepare('INSERT INTO ' . dg_prefix() . 'login_attempts (email, fails, last_at) VALUES (?, 1, NOW()) ON DUPLICATE KEY UPDATE fails = fails + 1, last_at = NOW()');
    $st->execute(array(strtolower($email)));
    $row = dg_login_attempt_row($email);
    if ($row && (int) $row['fails'] >= 6) {
        $pdo->prepare('UPDATE ' . dg_prefix() . 'login_attempts SET locked_until = DATE_ADD(NOW(), INTERVAL 10 MINUTE) WHERE email = ?')->execute(array(strtolower($email)));
    }
}

function dg_login_clear($email) {
    dg_db()->prepare('DELETE FROM ' . dg_prefix() . 'login_attempts WHERE email = ?')->execute(array(strtolower($email)));
}

// ------------------------------------------------------------------ auth

function dg_current_user() {
    static $cache = false;
    if ($cache !== false) {
        return $cache['row'] ? $cache['row'] : null;
    }
    $cache = array('row' => null);
    if (empty($_SESSION['uid'])) {
        return null;
    }
    $st = dg_db()->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ? LIMIT 1');
    $st->execute(array((int) $_SESSION['uid']));
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if ($row && $row['status'] === 'Active') {
        $cache['row'] = $row;
    }
    return $cache['row'];
}

function dg_require_user() {
    $user = dg_current_user();
    if (!$user) {
        dg_fail(401, 'আগে লগইন করুন।');
    }
    return $user;
}

function dg_require_admin() {
    $user = dg_require_user();
    if ($user['role'] !== 'admin') {
        dg_fail(403, 'Admin access required.');
    }
    return $user;
}

function dg_login_session($row) {
    session_regenerate_id(true);
    $_SESSION['uid'] = (int) $row['id'];
    $_SESSION['role'] = $row['role'];
    dg_db()->prepare('UPDATE ' . dg_prefix() . 'users SET last_login_at = NOW() WHERE id = ?')->execute(array((int) $row['id']));
}

// Finances + profile payload returned by login/register/google/state.
function dg_me_payload($user) {
    $pdo = dg_db();
    $codes = array();
    $st = $pdo->prepare('SELECT code, reward, created_at FROM ' . dg_prefix() . 'redeemed_codes WHERE user_id = ? ORDER BY id DESC LIMIT 100');
    $st->execute(array((int) $user['id']));
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $codes[] = array('code' => $row['code'], 'reward' => (int) $row['reward'], 'date' => dg_stamp($row['created_at']));
    }
    $usage = null;
    $st = $pdo->prepare('SELECT day, count, paid FROM ' . dg_prefix() . 'spin_usage WHERE user_id = ? AND day = ?');
    $st->execute(array((int) $user['id'], date('Y-m-d')));
    $spin = $st->fetch(PDO::FETCH_ASSOC);
    if ($spin) {
        $usage = array('date' => $spin['day'], 'count' => (int) $spin['count'], 'paid' => (int) $spin['paid']);
    }
    $topup = 0.0;
    $st = $pdo->prepare('SELECT COALESCE(SUM(amount), 0) AS total FROM ' . dg_prefix() . 'deposits WHERE user_id = ? AND status = "Approved"');
    $st->execute(array((int) $user['id']));
    $topup = (float) $st->fetchColumn();
    return array(
        'account' => dg_profile($user),
        'wallet' => (float) $user['balance'],
        'coins' => (int) $user['coins'],
        'codes' => $codes,
        'spendPoints' => (int) $user['spend_points'],
        'lifetimeSpend' => (float) $user['lifetime_spend'],
        'lifetimeTopup' => $topup,
        'spinUsage' => $usage,
    );
}

function dg_profile($row) {
    return array(
        'name' => $row['name'],
        'email' => $row['email'],
        'phone' => $row['phone'],
        'premium' => (bool) $row['premium'],
        'verified' => (bool) $row['verified'],
        'supportPin' => $row['support_pin'],
        'level' => (int) $row['level'],
        'rank' => $row['rank_name'],
        'joined' => $row['joined'] ? date('d-m-Y', strtotime($row['joined'])) : '',
        'picture' => isset($row['picture']) ? $row['picture'] : '',
        'provider' => isset($row['provider']) ? $row['provider'] : 'password',
    );
}

// ------------------------------------------------------------------ admin logs

function dg_admin_log($adminRow, $action, $details) {
    try {
        $st = dg_db()->prepare('INSERT INTO ' . dg_prefix() . 'admin_logs (admin_id, admin_email, action, details, ip, user_agent) VALUES (?, ?, ?, ?, ?, ?)');
        $st->execute(array(
            $adminRow ? (int) $adminRow['id'] : null,
            $adminRow ? $adminRow['email'] : '',
            substr($action, 0, 64),
            substr((string) $details, 0, 2000),
            dg_client_ip(),
            substr(isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '', 0, 255),
        ));
    } catch (Exception $e) {
        /* logging must never break the request */
    }
}

// ------------------------------------------------------------------ settings / content

function dg_settings_get($key, $default = null) {
    $st = dg_db()->prepare('SELECT v FROM ' . dg_prefix() . 'settings WHERE k = ?');
    $st->execute(array($key));
    $row = $st->fetch(PDO::FETCH_ASSOC);
    return $row ? $row['v'] : $default;
}

function dg_settings_set($key, $value) {
    $st = dg_db()->prepare('INSERT INTO ' . dg_prefix() . 'settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)');
    $st->execute(array($key, $value));
}

function dg_content() {
    $raw = dg_settings_get('content', null);
    if ($raw === null || $raw === '') {
        return array();
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : array();
}

function dg_save_content($content) {
    dg_settings_set('content', json_encode($content, JSON_UNESCAPED_UNICODE));
    dg_bump_rev('content');
}

function dg_meta_get($key, $default = '0') {
    $st = dg_db()->prepare('SELECT v FROM ' . dg_prefix() . 'meta WHERE k = ?');
    $st->execute(array($key));
    $row = $st->fetch(PDO::FETCH_ASSOC);
    return $row ? $row['v'] : $default;
}

function dg_meta_set($key, $value) {
    $st = dg_db()->prepare('INSERT INTO ' . dg_prefix() . 'meta (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)');
    $st->execute(array($key, $value));
}

function dg_bump_rev($which) {
    $key = $which === 'content' ? 'rev_c' : 'rev_a';
    $next = (int) dg_meta_get($key, '0') + 1;
    dg_meta_set($key, (string) $next);
    return $next;
}

// Public copy of the admin content: server-only secrets are stripped so no
// token, API key or client secret ever reaches a normal visitor's browser.
function dg_public_content($content) {
    $clean = $content;
    if (isset($clean['site']) && is_array($clean['site'])) {
        $site = $clean['site'];
        foreach (array('autoApiKey', 'autoApiUrl', 'telegramBotToken', 'telegramChatId', 'googleClientSecret', 'providerPackages') as $key) {
            unset($site[$key]);
        }
        $clean['site'] = $site;
    }
    return $clean;
}

// ------------------------------------------------------------------ row mappers (DB → exact UI shapes)

function dg_stamp($mysqlDatetime) {
    if (!$mysqlDatetime) {
        return '';
    }
    $time = strtotime($mysqlDatetime);
    if (!$time) {
        return '';
    }
    return date('d-m-Y, h:i:s A', $time);
}

function dg_order_row($r) {
    $ref = null;
    if (!empty($r['payment_ref'])) {
        $decoded = json_decode($r['payment_ref'], true);
        if (is_array($decoded)) {
            $ref = array(
                'method' => isset($decoded['method']) ? $decoded['method'] : '',
                'sender' => isset($decoded['sender']) ? $decoded['sender'] : '',
                'trxId' => isset($decoded['trxId']) ? $decoded['trxId'] : '',
                'at' => isset($decoded['at']) ? $decoded['at'] : '',
            );
        }
    }
    return array(
        'id' => (int) $r['id'],
        'date' => dg_stamp($r['created_at']),
        'updated' => dg_stamp($r['updated_at']),
        'productName' => $r['product_name'],
        'packageName' => $r['package_name'],
        'price' => (float) $r['price'],
        'discount' => (float) $r['discount'],
        'voucherCode' => $r['voucher_code'],
        'playerId' => $r['player_id'],
        'playerLabel' => $r['player_label'],
        'playerName' => isset($r['player_name']) ? $r['player_name'] : '',
        'payment' => $r['payment'],
        'walletPaid' => (bool) $r['wallet_paid'],
        'gatewayPay' => (bool) $r['gateway_pay'],
        'payStatus' => $r['pay_status'],
        'paymentRef' => $ref,
        'clientOrderId' => $r['client_order_id'],
        'apiPackageId' => $r['api_package_id'],
        'quantity' => (int) $r['quantity'],
        'autoStatus' => $r['auto_status'] === null ? null : $r['auto_status'],
        'providerOrderid' => $r['provider_orderid'],
        'autoNote' => isset($r['auto_note']) ? (string) $r['auto_note'] : '',
        'refunded' => (bool) $r['refunded'],
        'status' => $r['status'],
        'message' => isset($r['message']) ? (string) $r['message'] : '',
        'userEmail' => $r['user_email'],
        'userName' => $r['user_name'],
    );
}

function dg_order_public_row($r) {
    $row = dg_order_row($r);
    unset($row['playerId'], $row['paymentRef'], $row['apiPackageId'], $row['userEmail']);
    return $row;
}

function dg_deposit_row($r) {
    return array(
        'id' => 'dp-' . $r['id'],
        'user' => $r['user_name'],
        'email' => $r['user_email'],
        'method' => $r['method'],
        'amount' => (float) $r['amount'],
        'sender' => $r['sender'],
        'trxId' => $r['trx_id'],
        'gateway' => (bool) $r['gateway'],
        'status' => $r['status'],
        'date' => dg_stamp($r['created_at']),
        'updated' => dg_stamp($r['updated_at']),
        'credited' => (bool) $r['credited'],
    );
}

function dg_balance_log_row($r) {
    return array(
        'id' => 'bal-' . $r['id'],
        'user' => $r['user_name'],
        'email' => $r['user_email'],
        'type' => $r['type'],
        'amount' => (float) $r['amount'],
        'balanceAfter' => (float) $r['balance_after'],
        'note' => $r['note'],
        'applied' => true,
        'date' => dg_stamp($r['created_at']),
    );
}

function dg_spin_log_row($r) {
    return array(
        'id' => 'sl-' . $r['id'],
        'user' => $r['user_name'],
        'email' => $r['user_email'],
        'item' => $r['item'],
        'reward' => $r['reward'],
        'date' => dg_stamp($r['created_at']),
        'status' => $r['status'],
    );
}

function dg_referral_row($r) {
    return array(
        'id' => 'rf-' . $r['id'],
        'user' => $r['code'],
        'email' => $r['referred_email'],
        'code' => $r['code'],
        'referred' => $r['referred_email'],
        'reward' => (float) $r['reward'],
        'status' => $r['status'],
        'date' => dg_stamp($r['created_at']),
        'updated' => dg_stamp($r['updated_at']),
        'paid' => (bool) $r['paid'],
    );
}

function dg_coin_row($r) {
    return array(
        'id' => 'cc-' . $r['id'],
        'user' => $r['user_name'],
        'email' => $r['user_email'],
        'coins' => (int) $r['coins'],
        'amount' => (float) $r['amount'],
        'date' => dg_stamp($r['created_at']),
        'status' => $r['status'],
    );
}

function dg_admin_user_row($r) {
    return array(
        'id' => 'usr-' . $r['id'],
        'name' => $r['name'],
        'email' => $r['email'],
        'phone' => $r['phone'],
        'role' => $r['role'] === 'admin' ? 'ADMIN' : 'USER',
        'balance' => (float) $r['balance'],
        'status' => $r['status'],
        'premium' => (bool) $r['premium'],
        'verified' => (bool) $r['verified'],
        'reseller' => (bool) $r['reseller'],
        'joined' => $r['joined'] ? date('d-m-Y', strtotime($r['joined'])) : '',
    );
}

// ------------------------------------------------------------------ money ops (always inside a caller transaction)

function dg_balance_log($user, $type, $amount, $balanceAfter, $note, $adminRow = null) {
    $st = dg_db()->prepare('INSERT INTO ' . dg_prefix() . 'balance_logs (user_id, user_email, user_name, type, amount, balance_after, note, admin_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $st->execute(array(
        $user ? (int) $user['id'] : null,
        $user ? $user['email'] : '',
        $user ? $user['name'] : '',
        $type === 'Deduct' ? 'Deduct' : 'Add',
        round((float) $amount, 2),
        round((float) $balanceAfter, 2),
        substr((string) $note, 0, 255),
        $adminRow ? (int) $adminRow['id'] : null,
    ));
}

function dg_apply_balance($user, $delta, $note, $adminRow = null) {
    $pdo = dg_db();
    $delta = round((float) $delta, 2);
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ? FOR UPDATE');
    $st->execute(array((int) $user['id']));
    $fresh = $st->fetch(PDO::FETCH_ASSOC);
    if (!$fresh) {
        return null;
    }
    $newBalance = round(max(0, (float) $fresh['balance'] + $delta), 2);
    $pdo->prepare('UPDATE ' . dg_prefix() . 'users SET balance = ? WHERE id = ?')->execute(array($newBalance, (int) $fresh['id']));
    $type = $delta >= 0 ? 'Add' : 'Deduct';
    dg_balance_log($fresh, $type, abs($delta), $newBalance, $note, $adminRow);
    $fresh['balance'] = $newBalance;
    return $fresh;
}

// VIP Premium auto-upgrade: approved top-ups reach the admin's threshold.
function dg_vip_check($user, $content) {
    $site = isset($content['site']) && is_array($content['site']) ? $content['site'] : array();
    $threshold = isset($site['vipThreshold']) ? (float) $site['vipThreshold'] : 0;
    if ($threshold <= 0) {
        return false;
    }
    $pdo = dg_db();
    $st = $pdo->prepare('SELECT COALESCE(SUM(amount), 0) AS total FROM ' . dg_prefix() . 'deposits WHERE user_id = ? AND status = "Approved"');
    $st->execute(array((int) $user['id']));
    $total = (float) $st->fetchColumn();
    if ($total < $threshold) {
        return false;
    }
    $st = $pdo->prepare('SELECT premium FROM ' . dg_prefix() . 'users WHERE id = ?');
    $st->execute(array((int) $user['id']));
    if ((int) $st->fetchColumn() === 1) {
        return false;
    }
    $pdo->prepare('UPDATE ' . dg_prefix() . 'users SET premium = 1, rank_name = "Grand Master" WHERE id = ?')->execute(array((int) $user['id']));
    return true;
}

function dg_trx_id_used($trxId, $ignoreDepositId = 0, $ignoreOrderId = 0) {
    $clean = strtoupper(trim((string) $trxId));
    if ($clean === '') {
        return false;
    }
    $pdo = dg_db();
    $st = $pdo->prepare('SELECT id FROM ' . dg_prefix() . 'deposits WHERE UPPER(trx_id) = ? AND id != ? LIMIT 1');
    $st->execute(array($clean, (int) $ignoreDepositId));
    if ($st->fetch()) {
        return true;
    }
    $st = $pdo->prepare('SELECT id FROM ' . dg_prefix() . 'orders WHERE UPPER(JSON_UNQUOTE(JSON_EXTRACT(payment_ref, "$.trxId"))) = ? AND id != ? LIMIT 1');
    $st->execute(array($clean, (int) $ignoreOrderId));
    if ($st->fetch()) {
        return true;
    }
    $st = $pdo->prepare('SELECT id FROM ' . dg_prefix() . 'deposits WHERE UPPER(trx_id) = ?');
    $st->execute(array($clean));
    return (bool) $st->fetch();
}

// ------------------------------------------------------------------ rule engine (ports of the storefront helpers, server-authoritative)

function dg_rank_for($points) {
    if ($points >= 5000) {
        return 'Grand Master';
    }
    if ($points >= 500) {
        return 'Gold';
    }
    if ($points >= 100) {
        return 'Silver';
    }
    return 'Bronze';
}

function dg_active_flash_sale($content, $productId) {
    $list = isset($content['flashSale']) && is_array($content['flashSale']) ? $content['flashSale'] : array();
    $now = time();
    foreach ($list as $sale) {
        if (!is_array($sale) || isset($sale['active']) && $sale['active'] === false) {
            if (!is_array($sale)) {
                continue;
            }
        }
        if (!is_array($sale)) {
            continue;
        }
        if (isset($sale['active']) && $sale['active'] === false) {
            continue;
        }
        if (!isset($sale['product']) || $sale['product'] !== $productId) {
            continue;
        }
        if (!empty($sale['endsAt'])) {
            $ends = strtotime((string) $sale['endsAt']);
            if ($ends && $ends <= $now) {
                continue;
            }
        }
        return $sale;
    }
    return null;
}

function dg_flash_price($price, $discount) {
    $percent = min(99, max(0, (float) $discount));
    return max(1, (int) round(((float) $price * (100 - $percent)) / 100));
}

function dg_find_voucher($content, $code) {
    $clean = strtoupper(trim((string) $code));
    if ($clean === '') {
        return null;
    }
    $list = isset($content['vouchers']) && is_array($content['vouchers']) ? $content['vouchers'] : array();
    foreach ($list as $voucher) {
        if (!is_array($voucher) || empty($voucher['code'])) {
            continue;
        }
        if (strtoupper($voucher['code']) === $clean && !(isset($voucher['active']) && $voucher['active'] === false)) {
            return $voucher;
        }
    }
    return null;
}

function dg_voucher_discount($voucher, $subtotal) {
    if (!$voucher) {
        return 0;
    }
    $value = isset($voucher['value']) ? (float) $voucher['value'] : 0;
    if (isset($voucher['type']) && $voucher['type'] === 'percent') {
        return (int) min($subtotal, round(($subtotal * $value) / 100));
    }
    return (int) min($subtotal, max(0, round($value)));
}

function dg_best_auto_voucher($content, $subtotal) {
    $autos = isset($content['autoVouchers']) && is_array($content['autoVouchers']) ? $content['autoVouchers'] : array();
    $best = null;
    $bestCut = 0;
    foreach ($autos as $auto) {
        if (!is_array($auto) || (isset($auto['active']) && $auto['active'] === false)) {
            continue;
        }
        if ((float) (isset($auto['minSpend']) ? $auto['minSpend'] : 0) > $subtotal) {
            continue;
        }
        $voucher = dg_find_voucher($content, isset($auto['voucherCode']) ? $auto['voucherCode'] : '');
        if (!$voucher) {
            continue;
        }
        $cut = dg_voucher_discount($voucher, $subtotal);
        if ($cut > $bestCut) {
            $best = $voucher;
            $bestCut = $cut;
        }
    }
    return array('voucher' => $best, 'discount' => $bestCut);
}

// Per-product account input rules (must match src/utils.js INPUT_TYPES).
function dg_input_spec($type, $customLabel = '') {
    $specs = array(
        'uid' => array('shortName' => 'UID', 'pattern' => '/^\d{6,12}$/', 'hint' => '৬ থেকে ১২ ডিজিটের প্লেয়ার আইডি দিন।'),
        'email' => array('shortName' => 'Email', 'pattern' => '/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/', 'hint' => 'সঠিক ইমেইল অ্যাড্রেস দিন।'),
        'phone' => array('shortName' => 'Phone No', 'pattern' => '/^(?:880|88)?0?1[3-9]\d{8}$/', 'hint' => '১১ ডিজিটের সঠিক ফোন নাম্বার দিন।'),
        'whatsapp' => array('shortName' => 'WhatsApp No', 'pattern' => '/^(?:880|88)?0?1[3-9]\d{8}$/', 'hint' => 'সঠিক WhatsApp নাম্বার দিন (১১ ডিজিট)।'),
        'username' => array('shortName' => 'Username', 'pattern' => '/^.{3,}$/s', 'hint' => 'আপনার সঠিক গেম ইউজারনেম লিখুন।'),
        'custom' => array('shortName' => '', 'pattern' => '/^.{2,}$/s', 'hint' => 'সঠিক তথ্য লিখুন।'),
    );
    $spec = isset($specs[$type]) ? $specs[$type] : $specs['uid'];
    if ($type === 'custom' && trim((string) $customLabel) !== '') {
        $spec['shortName'] = trim((string) $customLabel);
    }
    if ($spec['shortName'] === '') {
        $spec['shortName'] = 'Info';
    }
    return $spec;
}

function dg_input_valid($spec, $value) {
    return (bool) preg_match($spec['pattern'], trim((string) $value));
}

// Spin wheel items (must match utils.js activeSpinItems/pickSpinItem).
function dg_default_spin_items() {
    return array(
        array('id' => 'd-spin-1', 'label' => '50 Coins', 'rewardType' => 'coins', 'reward' => 50, 'weight' => 30, 'active' => true),
        array('id' => 'd-spin-2', 'label' => '৳10 Cashback', 'rewardType' => 'amount', 'reward' => 10, 'weight' => 20, 'active' => true),
        array('id' => 'd-spin-3', 'label' => 'Try Again', 'rewardType' => 'none', 'reward' => 0, 'weight' => 25, 'active' => true),
        array('id' => 'd-spin-4', 'label' => '100 Coins', 'rewardType' => 'coins', 'reward' => 100, 'weight' => 15, 'active' => true),
        array('id' => 'd-spin-5', 'label' => '৳25 Cashback', 'rewardType' => 'amount', 'reward' => 25, 'weight' => 7, 'active' => true),
        array('id' => 'd-spin-6', 'label' => '200 Coins', 'rewardType' => 'coins', 'reward' => 200, 'weight' => 3, 'active' => true),
    );
}

function dg_active_spin_items($content) {
    $items = isset($content['spinItems']) && is_array($content['spinItems']) ? $content['spinItems'] : array();
    $active = array();
    foreach ($items as $item) {
        if (is_array($item) && !(isset($item['active']) && $item['active'] === false)) {
            $active[] = $item;
        }
    }
    return count($active) >= 2 ? $active : dg_default_spin_items();
}

function dg_pick_spin_item($items) {
    $total = 0;
    foreach ($items as $item) {
        $total += max(0, (float) (isset($item['weight']) ? $item['weight'] : 0));
    }
    $roll = $total > 0 ? (mt_rand() / mt_getrandmax()) * $total : (mt_rand() / mt_getrandmax()) * count($items);
    $last = null;
    foreach ($items as $item) {
        $last = $item;
        $weight = max(0, (float) (isset($item['weight']) ? $item['weight'] : 0));
        if ($total <= 0) {
            $weight = 1;
        }
        $roll -= $weight;
        if ($roll <= 0) {
            return $item;
        }
    }
    return $last ? $last : $items[0];
}

// ------------------------------------------------------------------ Telegram (server-side, fire-and-forget)

function dg_telegram_send($site, $text) {
    $token = isset($site['telegramBotToken']) ? trim((string) $site['telegramBotToken']) : '';
    $chat = isset($site['telegramChatId']) ? trim((string) $site['telegramChatId']) : '';
    if ($token === '' || $chat === '') {
        return false;
    }
    $payload = json_encode(array('chat_id' => $chat, 'text' => $text), JSON_UNESCAPED_UNICODE);
    if (function_exists('curl_init')) {
        $ch = curl_init('https://api.telegram.org/bot' . $token . '/sendMessage');
        curl_setopt_array($ch, array(
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 8,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_HTTPHEADER => array('Content-Type: application/json'),
        ));
        curl_exec($ch);
        curl_close($ch);
        return true;
    }
    $context = stream_context_create(array('http' => array(
        'method' => 'POST',
        'header' => "Content-Type: application/json\r\n",
        'content' => $payload,
        'timeout' => 8,
        'ignore_errors' => true,
    )));
    @file_get_contents('https://api.telegram.org/bot' . $token . '/sendMessage', false, $context);
    return true;
}

function dg_telegram_notify($site, $text) {
    if (!is_array($site)) {
        return;
    }
    if (array_key_exists('telegramEnabled', $site) && $site['telegramEnabled'] === false) {
        return;
    }
    dg_telegram_send($site, $text);
}

function dg_dash($value) {
    $text = trim((string) ($value === null ? '' : $value));
    return $text === '' ? '—' : $text;
}

function dg_taka($site, $amount) {
    $symbol = (is_array($site) && isset($site['symbol']) && $site['symbol']) ? $site['symbol'] : '৳';
    return $symbol . round((float) $amount);
}

function dg_dmy($time = null) {
    return date('d M Y', $time === null ? time() : $time);
}

function dg_product_line($order) {
    $text = dg_dash($order['product_name']);
    if ($order['package_name'] !== '' && $order['package_name'] !== $order['product_name']) {
        $text .= ' - ' . $order['package_name'];
    }
    if ((int) $order['quantity'] > 1) {
        $text .= ' (x' . (int) $order['quantity'] . ')';
    }
    return $text;
}

function dg_msg_order($order, $site) {
    $label = $order['player_label'] === 'UID' || $order['player_label'] === '' ? 'Player UID' : $order['player_label'];
    return implode("\n", array(
        '🛒 NEW ORDER RECEIVED!',
        '',
        '━━━━━━━━━━━━━━━',
        '📦 Order ID: #' . dg_dash($order['id']),
        '👤 Customer: ' . dg_dash($order['user_name']),
        '🎮 Product: ' . dg_product_line($order),
        '🆔 ' . $label . ': ' . dg_dash($order['player_id']),
        '💰 Amount: ' . dg_taka($site, $order['price']),
        '📅 Date: ' . dg_dmy(),
        '📌 Status: ' . dg_dash($order['status']),
        '━━━━━━━━━━━━━━━',
        '',
        '🔔 Please check your admin panel.',
    ));
}

function dg_msg_order_payment($order, $ref, $site) {
    return implode("\n", array(
        '💳 ORDER PAYMENT SUBMITTED!',
        '',
        '━━━━━━━━━━━━━━━',
        '📦 Order ID: #' . dg_dash($order['id']),
        '👤 Customer: ' . dg_dash($order['user_name']),
        '🎮 Product: ' . dg_product_line($order),
        '💰 Amount: ' . dg_taka($site, $order['price']),
        '💳 Payment Method: ' . dg_dash(isset($ref['method']) ? $ref['method'] : ''),
        '📱 Sender Number: ' . dg_dash(isset($ref['sender']) ? $ref['sender'] : ''),
        '🔖 Transaction ID: ' . dg_dash(isset($ref['trxId']) ? $ref['trxId'] : ''),
        '📅 Date: ' . dg_dmy(),
        '📌 Status: Verifying',
        '━━━━━━━━━━━━━━━',
        '',
        '🔔 Please verify the payment.',
    ));
}

function dg_msg_payment_verified($order, $site) {
    return implode("\n", array(
        '✅ ORDER PAYMENT VERIFIED!',
        '',
        '━━━━━━━━━━━━━━━',
        '📦 Order ID: #' . dg_dash($order['id']),
        '👤 Customer: ' . dg_dash($order['user_name']),
        '🎮 Product: ' . dg_product_line($order),
        '💰 Amount: ' . dg_taka($site, $order['price']),
        '🔖 Transaction ID: ' . dg_dash(isset($order['payment_ref']) ? '' : ''),
        '📅 Date: ' . dg_dmy(),
        '📌 Status: Processing',
        '━━━━━━━━━━━━━━━',
        '',
        '🔔 Payment verified from the admin panel.',
    ));
}

function dg_msg_deposit($deposit, $userRef, $site) {
    return implode("\n", array(
        '💰 NEW ADD MONEY REQUEST!',
        '',
        '━━━━━━━━━━━━━━━',
        '👤 User: ' . dg_dash($deposit['user_name']),
        '🆔 User ID: ' . dg_dash($userRef),
        '💳 Payment Method: ' . dg_dash($deposit['method']),
        '📱 Sender Number: ' . dg_dash($deposit['sender']),
        '🔖 Transaction ID: ' . dg_dash($deposit['trx_id']),
        '💵 Amount: ' . dg_taka($site, $deposit['amount']),
        '📌 Status: ' . dg_dash($deposit['status']),
        '━━━━━━━━━━━━━━━',
        '',
        '🔔 Please verify the payment.',
    ));
}

function dg_msg_spin_win($userName, $userRef, $item, $productName, $site) {
    return implode("\n", array(
        '🎁 SPIN WHEEL — PRODUCT WON!',
        '',
        '━━━━━━━━━━━━━━━',
        '👤 User: ' . dg_dash($userName),
        '🆔 User ID: ' . dg_dash($userRef),
        '🎡 Spin item: ' . dg_dash($item),
        '📦 Product to deliver: ' . dg_dash($productName),
        '📅 Date: ' . dg_dmy(),
        '📌 Status: Pending (Spin Logs)',
        '━━━━━━━━━━━━━━━',
        '',
        '🔔 Please deliver the product and mark the spin Completed in the admin panel.',
    ));
}

function dg_msg_balance($user, $type, $amount, $note) {
    return implode("\n", array(
        $type === 'Deduct' ? '⚠️ WALLET BALANCE DEDUCTED!' : '💼 WALLET BALANCE ADDED!',
        '',
        '━━━━━━━━━━━━━━━',
        '👤 User: ' . dg_dash($user['name']),
        '🆔 User ID: usr-' . (int) $user['id'],
        '📧 Email: ' . dg_dash($user['email']),
        '💰 Amount: ' . round((float) $amount, 2),
        '📌 Type: ' . $type,
        '📝 Note: ' . dg_dash($note),
        '📅 Date: ' . dg_dmy(),
        '━━━━━━━━━━━━━━━',
        '',
        '🔐 Security notification — if you did not expect this, contact support.',
    ));
}

function dg_msg_admin_login($user, $ok) {
    return implode("\n", array(
        $ok ? '🔐 ADMIN LOGIN (SUCCESS)' : '🚨 ADMIN LOGIN FAILED',
        '',
        '━━━━━━━━━━━━━━━',
        '📧 Email: ' . dg_dash($user['email']),
        '🌐 IP: ' . dg_client_ip(),
        '📅 Date: ' . dg_dmy(),
        '━━━━━━━━━━━━━━━',
        '',
        $ok ? 'An administrator signed in to the panel.' : 'Someone failed to sign in as admin. If this was not you, change the admin password.',
    ));
}

// ------------------------------------------------------------------ reseller / provider API helpers (server-side only)

function dg_provider_base($rawUrl) {
    $base = trim((string) $rawUrl);
    $base = rtrim($base, '/');
    $base = preg_replace('#/api/(variations|place-order|webhook-receiver|order-status)(\.php)?$#i', '', $base);
    return rtrim($base, '/');
}

function dg_provider_post($url, $payload) {
    $json = json_encode($payload);
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $json,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER => array('Content-Type: application/json', 'Accept: application/json'),
        ));
        $res = curl_exec($ch);
        $err = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($res === false) {
            return array('error' => 'Provider request failed: ' . $err);
        }
        return array('code' => (int) $code, 'body' => $res);
    }
    $context = stream_context_create(array('http' => array(
        'method' => 'POST',
        'header' => "Content-Type: application/json\r\nAccept: application/json\r\n",
        'content' => $json,
        'timeout' => 30,
        'ignore_errors' => true,
    )));
    $res = @file_get_contents($url, false, $context);
    if ($res === false) {
        return array('error' => 'Provider request failed (cURL missing and allow_url_fopen disabled).');
    }
    $code = 0;
    if (isset($http_response_header) && is_array($http_response_header)) {
        foreach ($http_response_header as $line) {
            if (preg_match('#HTTP/\S+\s+(\d{3})#', $line, $m)) {
                $code = (int) $m[1];
            }
        }
    }
    return array('code' => $code, 'body' => $res);
}

function dg_hint_for($status) {
    if ($status === 401 || $status === 403) {
        return 'API secret key bhul naki reseller account disabled — Admin → Settings → Auto Topup API te key ta abar check korun.';
    }
    if ($status === 404 || $status === 405) {
        return 'Provider URL thik naki dekhun — shudhu base URL din (jemon https://provider.com), puro endpoint URL na.';
    }
    if ($status === 429) {
        return 'Provider host theke request block hoiche (firewall/Cloudflare) — provider er support e jogajog korun.';
    }
    if ($status >= 500) {
        return 'Provider er nijer server e somossa — ektu por abar try korun.';
    }
    return '';
}

function dg_provider_failure($status, $body, $fallback) {
    $data = json_decode((string) $body, true);
    if (is_array($data) && isset($data['message']) && is_string($data['message']) && $data['message'] !== '') {
        return array('error' => 'Provider (' . (int) $status . '): ' . $data['message'], 'hint' => dg_hint_for((int) $status));
    }
    $snippet = trim(preg_replace('/\s+/', ' ', (string) $body));
    $snippet = function_exists('mb_substr') ? mb_substr($snippet, 0, 140) : substr($snippet, 0, 140);
    $detail = $snippet !== '' ? ' Response: "' . $snippet . '"' : '';
    $hint = dg_hint_for((int) $status);
    if ($hint === '') {
        $hint = 'Provider URL thik naki dekhun — shudhu base URL din (jemon https://provider.com), puro endpoint URL na.';
    }
    return array('error' => 'Provider HTTP ' . (int) $status . ' response dilo kintu JSON ashe ni.' . $detail, 'hint' => $hint);
}

function dg_webhook_url($key) {
    return dg_site_base() . '/api/webhook-receiver.php?key=' . $key;
}

// Sends a placed order to the auto-topup provider (secrets come from the
// server-side settings, never from the browser). $refundOnFail mirrors the
// storefront behaviour: a wallet order the provider rejects is refunded.
function dg_forward_to_provider($orderRow, $content, $refundOnFail) {
    $site = isset($content['site']) && is_array($content['site']) ? $content['site'] : array();
    $apiUrl = dg_provider_base(isset($site['autoApiUrl']) ? $site['autoApiUrl'] : '');
    $apiKey = isset($site['autoApiKey']) ? trim((string) $site['autoApiKey']) : '';
    $packageId = (string) $orderRow['api_package_id'];
    if (!isset($site['autoEnabled']) || !$site['autoEnabled'] || $apiUrl === '' || $apiKey === '' || $packageId === '') {
        return array('skipped' => true);
    }
    $webhookKey = bin2hex(random_bytes(24));
    $res = dg_provider_post($apiUrl . '/api/place-order', array(
        'secret_key' => $apiKey,
        'package_id' => $packageId,
        'player_id' => $orderRow['player_id'],
        'client_order_id' => $orderRow['client_order_id'],
        'quantity' => max(1, (int) $orderRow['quantity']),
        'webhook_url' => dg_webhook_url($webhookKey),
    ));
    $pdo = dg_db();
    if (isset($res['error'])) {
        if ($refundOnFail) {
            dg_refund_failed_order($orderRow, 'অটো সার্ভারে পাঠানো যায়নি (নেটওয়ার্ক সমস্যা)।');
        } else {
            $pdo->prepare('UPDATE ' . dg_prefix() . 'orders SET auto_note = ? WHERE id = ?')->execute(array('অটো সার্ভারে পাঠানো যায়নি।', (int) $orderRow['id']));
        }
        return array('ok' => false, 'error' => $res['error'], 'hint' => 'Provider site e network theke connect kora jayni. Host ta thik ase kina, ar hosting e outbound connection allow ase kina dekhun.');
    }
    $data = json_decode($res['body'], true);
    if (is_array($data) && isset($data['orderid']) && $data['orderid'] !== '') {
        $status = isset($data['status']) && $data['status'] !== '' ? (string) $data['status'] : 'processing';
        $contentText = isset($data['content']) ? (string) $data['content'] : '';
        $pdo->prepare('UPDATE ' . dg_prefix() . 'orders SET auto_status = ?, provider_orderid = ?, auto_note = ?, webhook_key = ? WHERE id = ?')
            ->execute(array($status !== '' ? $status : 'processing', (string) $data['orderid'], $contentText, $webhookKey, (int) $orderRow['id']));
        return array('ok' => true, 'data' => array('orderid' => (string) $data['orderid'], 'status' => $status, 'content' => $contentText));
    }
    $message = is_array($data) && isset($data['message']) && is_string($data['message']) && $data['message'] !== '' ? (string) $data['message'] : '';
    if ($message !== '' && stripos($message, 'duplicate') !== false) {
        $pdo->prepare('UPDATE ' . dg_prefix() . 'orders SET auto_status = "processing", auto_note = ?, webhook_key = ? WHERE id = ?')
            ->execute(array($message, $webhookKey, (int) $orderRow['id']));
        return array('ok' => true, 'duplicate' => true, 'data' => array('orderid' => '', 'status' => 'processing', 'content' => $message));
    }
    $failure = dg_provider_failure((int) $res['code'], $res['body'], 'Order rejected by provider.');
    $note = $message !== '' ? $message : $failure['error'];
    if ($refundOnFail) {
        dg_refund_failed_order($orderRow, $note);
    } else {
        $pdo->prepare('UPDATE ' . dg_prefix() . 'orders SET auto_note = ? WHERE id = ?')->execute(array($note, (int) $orderRow['id']));
    }
    return array('ok' => false, 'error' => $note, 'hint' => isset($failure['hint']) ? $failure['hint'] : '');
}

// Provider rejected (or could not receive) a wallet order: mark failed and
// put the money back into the wallet exactly once.
function dg_refund_failed_order($orderRow, $note) {
    $pdo = dg_db();
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'orders WHERE id = ? FOR UPDATE');
    $st->execute(array((int) $orderRow['id']));
    $order = $st->fetch(PDO::FETCH_ASSOC);
    if (!$order || (int) $order['refunded'] === 1) {
        return false;
    }
    $pdo->prepare('UPDATE ' . dg_prefix() . 'orders SET status = "Failed", auto_status = "error", auto_note = ?, refunded = 1, message = ? WHERE id = ?')
        ->execute(array(
            $note,
            'অর্ডারটি সম্পন্ন করা যায়নি (' . $note . ')। আপনার পেমেন্ট আপনার ওয়ালেটে ফেরত দেওয়া হয়েছে।',
            (int) $order['id'],
        ));
    if ((int) $order['wallet_paid'] === 1) {
        $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ?');
        $st->execute(array($order['user_id'] === null ? 0 : (int) $order['user_id']));
        $user = $st->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            dg_apply_balance($user, (float) $order['price'], 'Refund — order #' . $order['id'] . ' failed', null);
        }
    }
    dg_bump_rev('ledger');
    return true;
}

// Provider webhook result → final order state (success / error + refund).
function dg_apply_provider_status($orderRow, $status, $content) {
    $pdo = dg_db();
    $site = isset($content['site']) && is_array($content['site']) ? $content['site'] : array();
    if ($status === 'success') {
        $pdo->prepare('UPDATE ' . dg_prefix() . 'orders SET status = "Completed", auto_status = "success", message = CONCAT(?, COALESCE(auto_note, "")) WHERE id = ? AND status NOT IN ("Completed")')
            ->execute(array('আপনার ' . $orderRow['package_name'] . ' সফলভাবে ডেলিভারি দেওয়া হয়েছে। ', (int) $orderRow['id']));
        dg_bump_rev('ledger');
        dg_telegram_notify($site, implode("\n", array(
            '✅ ORDER COMPLETED (AUTO TOPUP)!',
            '',
            '📦 Order ID: #' . dg_dash($orderRow['id']),
            '👤 Customer: ' . dg_dash($orderRow['user_name']),
            '🎮 Product: ' . dg_product_line($orderRow),
            '📅 Date: ' . dg_dmy(),
        )));
        return true;
    }
    if ($status === 'error') {
        $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'orders WHERE id = ? FOR UPDATE');
        $st->execute(array((int) $orderRow['id']));
        $order = $st->fetch(PDO::FETCH_ASSOC);
        if (!$order || $order['auto_status'] === 'success' || $order['auto_status'] === 'error') {
            return false;
        }
        $refundNote = (int) $order['wallet_paid'] === 1 && (int) $order['refunded'] === 0 ? ' টাকা আপনার ওয়ালেটে ফেরত দেওয়া হয়েছে।' : '';
        $pdo->prepare('UPDATE ' . dg_prefix() . 'orders SET status = "Failed", auto_status = "error", refunded = 1, message = CONCAT(?, ?, ?) WHERE id = ?')
            ->execute(array('অর্ডারটি সম্পন্ন করা যায়নি (', (string) (isset($order['auto_note']) ? $order['auto_note'] : 'প্রোভাইডার এরর'), $refundNote . ')', (int) $order['id']));
        if ($refundNote !== '') {
            $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ?');
            $st->execute(array($order['user_id'] === null ? 0 : (int) $order['user_id']));
            $user = $st->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                dg_apply_balance($user, (float) $order['price'], 'Refund — order #' . $order['id'] . ' failed (provider)', null);
            }
        }
        dg_bump_rev('ledger');
        return true;
    }
    return false;
}
