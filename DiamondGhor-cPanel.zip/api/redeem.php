<?php
/**
 * DiamondGhor API — redeem a site code (server-side validation).
 * POST /api/redeem.php  { code }
 * Usage limits and one-time-per-account are enforced here; the coin reward
 * lands on the server-side wallet record and the used counter increments in
 * the stored content.
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dg_fail(405, 'POST only');
}

$pdo = dg_db();
$user = dg_require_user();
$body = dg_body();
dg_check_csrf($body);
dg_rate_limit('redeem', 20, 3600);

$code = strtoupper(trim((string) dg_field($body, 'code', '')));
if ($code === '') {
    dg_fail(400, 'কোড লিখুন।');
}

$content = dg_content();
$siteCodes = isset($content['siteCodes']) && is_array($content['siteCodes']) ? $content['siteCodes'] : array();
$found = null;
foreach ($siteCodes as $item) {
    if (is_array($item) && isset($item['code']) && $item['code'] === $code && !(isset($item['active']) && $item['active'] === false)) {
        $found = $item;
        break;
    }
}
if (!$found) {
    dg_fail(400, 'এই কোডটি সঠিক নয় বা মেয়াদ শেষ হয়েছে।');
}
if ((int) (isset($found['used']) ? $found['used'] : 0) >= (int) (isset($found['usageLimit']) && $found['usageLimit'] ? $found['usageLimit'] : 0)) {
    dg_fail(400, 'এই কোডটির ব্যবহারের সীমা শেষ হয়েছে।');
}
$st = $pdo->prepare('SELECT id FROM ' . dg_prefix() . 'redeemed_codes WHERE user_id = ? AND code = ?');
$st->execute(array((int) $user['id'], $code));
if ($st->fetch()) {
    dg_fail(400, 'আপনি এই কোডটি আগে ব্যবহার করেছেন।');
}

$reward = (int) (isset($found['reward']) ? $found['reward'] : 0);
$st = $pdo->prepare('INSERT INTO ' . dg_prefix() . 'redeemed_codes (user_id, code, reward) VALUES (?, ?, ?)');
$st->execute(array((int) $user['id'], $code, $reward));
$pdo->prepare('UPDATE ' . dg_prefix() . 'users SET coins = coins + ? WHERE id = ?')
    ->execute(array($reward, (int) $user['id']));

// Server-side usage counter on the stored content (counter-only change).
foreach ($siteCodes as $idx => $item) {
    if (is_array($item) && isset($item['code']) && $item['code'] === $code) {
        $content['siteCodes'][$idx]['used'] = (int) (isset($item['used']) ? $item['used'] : 0) + 1;
    }
}
dg_settings_set('content', json_encode($content, JSON_UNESCAPED_UNICODE));
dg_bump_rev('ledger');

$st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ?');
$st->execute(array((int) $user['id']));
$fresh = $st->fetch(PDO::FETCH_ASSOC);

dg_json_out(200, array(
    'ok' => true,
    'reward' => $reward,
    'coins' => $fresh ? (int) $fresh['coins'] : 0,
    'row' => array('code' => $code, 'reward' => $reward, 'date' => dg_stamp(date('Y-m-d H:i:s'))),
));
