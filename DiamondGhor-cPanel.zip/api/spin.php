<?php
/**
 * DiamondGhor API — spin the wheel (100% server-side).
 * POST /api/spin.php
 * The weighted pick, the daily free-spin limit, the coin charge and every
 * reward land on the server — the browser cannot choose its own prize or
 * reset the limit by clearing storage. The segment index is returned so the
 * wheel animates to the exact prize the server picked.
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dg_fail(405, 'POST only');
}

$pdo = dg_db();
$user = dg_require_user();
$body = dg_body();
dg_check_csrf($body);
dg_rate_limit('spin', 40, 60);

$content = dg_content();
$site = isset($content['site']) && is_array($content['site']) ? $content['site'] : array();
$freePerDay = max(0, (int) (isset($site['spinFreePerDay']) ? $site['spinFreePerDay'] : 0));
$costCoins = max(0, (int) (isset($site['spinCostCoins']) ? $site['spinCostCoins'] : 0));
$today = date('Y-m-d');

$pdo->beginTransaction();
try {
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ? FOR UPDATE');
    $st->execute(array((int) $user['id']));
    $fresh = $st->fetch(PDO::FETCH_ASSOC);
    if (!$fresh) {
        throw new Exception('user missing');
    }
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'spin_usage WHERE user_id = ? AND day = ?');
    $st->execute(array((int) $user['id'], $today));
    $usageRow = $st->fetch(PDO::FETCH_ASSOC);
    $count = $usageRow ? (int) $usageRow['count'] : 0;
    $paid = $usageRow ? (int) $usageRow['paid'] : 0;
    $freeLeft = max(0, $freePerDay - $count);
    $mustPay = $freeLeft === 0 && $costCoins > 0;
    if ($mustPay && (int) $fresh['coins'] < $costCoins) {
        $pdo->rollBack();
        dg_fail(400, 'ফ্রি স্পিন শেষ! আরও স্পিন করতে ' . $costCoins . ' কয়েন লাগবে (আপনার আছে ' . (int) $fresh['coins'] . ')।');
    }

    $items = dg_active_spin_items($content);
    $winner = dg_pick_spin_item($items);
    $segment = 0;
    foreach ($items as $idx => $item) {
        if ((isset($item['id']) ? $item['id'] : $idx) === (isset($winner['id']) ? $winner['id'] : null)) {
            $segment = $idx;
            break;
        }
    }
    $rewardType = isset($winner['rewardType']) ? $winner['rewardType'] : 'none';
    $rewardAmount = (int) (isset($winner['reward']) ? $winner['reward'] : 0);
    $wonProduct = null;
    if ($rewardType === 'product' && !empty($winner['rewardProduct'])) {
        foreach ((isset($content['products']) && is_array($content['products']) ? $content['products'] : array()) as $p) {
            if (is_array($p) && isset($p['id']) && $p['id'] === $winner['rewardProduct']) {
                $wonProduct = $p;
                break;
            }
        }
    }
    if ($rewardType === 'coins') {
        $rewardText = $rewardAmount . ' কয়েন';
    } elseif ($rewardType === 'amount') {
        $rewardText = '৳' . $rewardAmount . ' ক্যাশব্যাক';
    } elseif ($rewardType === 'product') {
        $rewardText = '🎁 ' . ($wonProduct && isset($wonProduct['name']) ? $wonProduct['name'] : (isset($winner['label']) ? $winner['label'] : 'Product'));
    } else {
        $rewardText = 'আবার চেষ্টা করুন';
    }

    $st = $pdo->prepare('INSERT INTO ' . dg_prefix() . 'spin_logs (user_id, user_email, user_name, item, reward, status) VALUES (?, ?, ?, ?, ?, ?)');
    $st->execute(array(
        (int) $user['id'],
        $user['email'],
        $user['name'],
        (string) (isset($winner['label']) ? $winner['label'] : ''),
        $rewardText,
        $rewardType === 'product' ? 'Pending' : 'Completed',
    ));

    $coinDelta = ($mustPay ? -$costCoins : 0) + ($rewardType === 'coins' ? $rewardAmount : 0);
    $walletDelta = $rewardType === 'amount' ? $rewardAmount : 0;
    $pdo->prepare('UPDATE ' . dg_prefix() . 'users SET coins = coins + ?, balance = balance + ? WHERE id = ?')
        ->execute(array($coinDelta, $walletDelta, (int) $user['id']));

    if ($usageRow) {
        $pdo->prepare('UPDATE ' . dg_prefix() . 'spin_usage SET count = count + 1, paid = paid + ? WHERE user_id = ? AND day = ?')
            ->execute(array($mustPay ? $costCoins : 0, (int) $user['id'], $today));
    } else {
        $pdo->prepare('INSERT INTO ' . dg_prefix() . 'spin_usage (user_id, day, count, paid) VALUES (?, ?, 1, ?)')
            ->execute(array((int) $user['id'], $today, $mustPay ? $costCoins : 0));
    }
    $pdo->commit();
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    dg_fail(500, 'Spin failed — একটু পরে আবার চেষ্টা করুন।');
}

dg_bump_rev('ledger');

// Product wins need manual delivery — the admin gets a Telegram push.
if ($rewardType === 'product') {
    dg_telegram_notify($site, dg_msg_spin_win(
        $user['name'],
        'usr-' . (int) $user['id'],
        isset($winner['label']) ? $winner['label'] : '',
        $wonProduct && isset($wonProduct['name']) ? $wonProduct['name'] : (isset($winner['label']) ? $winner['label'] : ''),
        $site
    ));
}

$st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ?');
$st->execute(array((int) $user['id']));
$fresh = $st->fetch(PDO::FETCH_ASSOC);

dg_json_out(200, array(
    'ok' => true,
    'winner' => $winner,
    'segment' => $segment,
    'total' => count($items),
    'rewardText' => $rewardText,
    'product' => $wonProduct ? array('id' => $wonProduct['id'], 'name' => isset($wonProduct['name']) ? $wonProduct['name'] : '') : null,
    'charged' => $mustPay ? $costCoins : 0,
    'coins' => $fresh ? (int) $fresh['coins'] : 0,
    'wallet' => $fresh ? (float) $fresh['balance'] : 0,
    'usage' => array('date' => $today, 'count' => $count + 1, 'paid' => $paid + ($mustPay ? $costCoins : 0)),
));
