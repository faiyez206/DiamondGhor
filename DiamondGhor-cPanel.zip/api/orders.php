<?php
/**
 * DiamondGhor API — place an order (server-side order processing).
 * POST /api/orders.php
 * { productId, variationId, playerId, inputType, inputLabel,
 *   method: "wallet" | "instant", voucherCode, quantity }
 *
 * The price is ALWAYS recomputed here from the stored content (products,
 * variations, flash sale, vouchers) — the browser's numbers are never
 * trusted. Wallet orders deduct the balance in one locked transaction;
 * instant-pay orders stay Pending/unpaid until the admin verifies payment.
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dg_fail(405, 'POST only');
}

$pdo = dg_db();
$user = dg_require_user();
$body = dg_body();
dg_check_csrf($body);
dg_rate_limit('orders', 30, 3600);

$content = dg_content();
$site = isset($content['site']) && is_array($content['site']) ? $content['site'] : array();

$productId = (string) dg_field($body, 'productId', '');
$variationId = (string) dg_field($body, 'variationId', '');
$playerId = (string) dg_field($body, 'playerId', '');
$inputType = (string) dg_field($body, 'inputType', 'uid');
$inputLabel = (string) dg_field($body, 'inputLabel', '');
$method = (string) dg_field($body, 'method', 'wallet') === 'instant' ? 'instant' : 'wallet';
$voucherCode = (string) dg_field($body, 'voucherCode', '');
$quantity = max(1, (int) dg_field($body, 'quantity', 1));

if (!$user || $user['status'] !== 'Active') {
    dg_fail(403, 'এই একাউন্টটি ব্লক করা হয়েছে। সাপোর্টে যোগাযোগ করুন।');
}

$product = null;
foreach ((isset($content['products']) && is_array($content['products']) ? $content['products'] : array()) as $item) {
    if (is_array($item) && isset($item['id']) && (string) $item['id'] === $productId && !(isset($item['active']) && $item['active'] === false)) {
        $product = $item;
        break;
    }
}
$variation = null;
foreach ((isset($content['variations']) && is_array($content['variations']) ? $content['variations'] : array()) as $item) {
    if (is_array($item) && isset($item['id']) && (string) $item['id'] === $variationId && isset($item['product']) && (string) $item['product'] === $productId && !(isset($item['active']) && $item['active'] === false)) {
        $variation = $item;
        break;
    }
}
if (!$product || !$variation) {
    dg_fail(400, 'প্যাকেজটি পাওয়া যায়নি — আবার সিলেক্ট করুন।');
}
if (!empty($product['premium']) && !$user['premium']) {
    dg_fail(403, 'এটি প্রিমিয়াম প্যাকেজ — VIP সদস্যরা অর্ডার করতে পারবেন।');
}
$spec = dg_input_spec($product['inputType'] ?? 'uid', isset($product['inputLabel']) ? $product['inputLabel'] : '');
if (!dg_input_valid($spec, $playerId)) {
    dg_fail(400, $spec['shortName'] . ' সঠিকভাবে লিখুন। ' . $spec['hint']);
}
if (!isset($variation['price']) || (float) $variation['price'] <= 0) {
    dg_fail(400, 'প্যাকেজের দাম সঠিক নয়।');
}

// ---- server-authoritative pricing (mirrors the storefront exactly) ----
$listPrice = (float) $variation['price'];
$sale = dg_active_flash_sale($content, $productId);
$subtotal = $sale ? dg_flash_price($listPrice, isset($sale['discount']) ? $sale['discount'] : 0) : (int) round($listPrice);
$auto = dg_best_auto_voucher($content, $subtotal);
$autoDiscount = (int) $auto['discount'];
$manualVoucher = null;
if ($voucherCode !== '') {
    $manualVoucher = dg_find_voucher($content, $voucherCode);
    if (!$manualVoucher) {
        dg_fail(400, 'ভাউচার কোড সঠিক নয় বা নিষ্ক্রিয়।');
    }
    if ((float) (isset($manualVoucher['minSpend']) ? $manualVoucher['minSpend'] : 0) > $subtotal) {
        dg_fail(400, 'এই ভাউচারে সর্বনিম্ন ৳' . (int) $manualVoucher['minSpend'] . ' অর্ডার লাগবে।');
    }
    if ((int) (isset($manualVoucher['used']) ? $manualVoucher['used'] : 0) >= (int) (isset($manualVoucher['usageLimit']) ? $manualVoucher['usageLimit'] : 0)) {
        dg_fail(400, 'এই ভাউচারের ব্যবহারের সীমা শেষ।');
    }
}
$voucherCut = $manualVoucher ? dg_voucher_discount($manualVoucher, $subtotal) : 0;
$total = max(0, $subtotal - $voucherCut - $autoDiscount);
if ($total <= 0) {
    dg_fail(400, 'প্যাকেজের দাম সঠিক নয়।');
}
$discountTotal = $voucherCut + $autoDiscount;

$gateway = $method === 'instant';
$walletPaid = !$gateway;
$apiPackageId = isset($variation['apiPackageId']) ? trim((string) $variation['apiPackageId']) : '';
$willAuto = !empty($site['autoEnabled']) && trim(isset($site['autoApiUrl']) ? $site['autoApiUrl'] : '') !== '' && trim(isset($site['autoApiKey']) ? $site['autoApiKey'] : '') !== '' && $apiPackageId !== '';

$gatewayMessage = 'পেমেন্ট ভেরিফিকেশনের অপেক্ষায়। পেমেন্ট শেষ করে TrxID জমা দিন — অ্যাডমিন কনফার্ম করলে অর্ডার প্রসেসিং-এ যাবে।';
$walletMessage = 'আপনার ' . $variation['name'] . ' অর্ডার প্রসেসিং-এ আছে। শীঘ্রই ডেলিভারি দেওয়া হবে। DIAMONDGHOR এর সাথে থাকার জন্য ধন্যবাদ।';

// ---- transaction: lock the wallet row, deduct, insert the order ----
$pdo->beginTransaction();
try {
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ? FOR UPDATE');
    $st->execute(array((int) $user['id']));
    $fresh = $st->fetch(PDO::FETCH_ASSOC);
    if (!$fresh) {
        throw new Exception('user missing');
    }
    if ($walletPaid && (float) $fresh['balance'] < $total) {
        $pdo->rollBack();
        dg_fail(400, 'আপনার ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই।');
    }
    $st = $pdo->prepare('INSERT INTO ' . dg_prefix() . 'orders
        (user_id, user_email, user_name, product_name, package_name, price, discount, voucher_code,
         player_id, player_label, payment, wallet_paid, gateway_pay, pay_status, client_order_id,
         api_package_id, quantity, auto_status, status, message)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "", ?, ?, ?, ?, ?)');
    $st->execute(array(
        (int) $user['id'],
        $user['email'],
        $user['name'],
        (string) $product['name'],
        (string) $variation['name'],
        $total,
        $discountTotal,
        $manualVoucher && isset($manualVoucher['code']) ? (string) $manualVoucher['code'] : '',
        $playerId,
        $spec['shortName'],
        $gateway ? (string) (isset($site['paymentBrand']) && $site['paymentBrand'] !== '' ? $site['paymentBrand'] : 'Gateway') . ' Pay' : 'Wallet Pay',
        $walletPaid ? 1 : 0,
        $gateway ? 1 : 0,
        $gateway ? 'unpaid' : 'paid',
        $apiPackageId,
        $quantity,
        ($willAuto && !$gateway) ? 'processing' : null,
        $gateway ? 'Pending' : 'Processing',
        $gateway ? $gatewayMessage : $walletMessage,
    ));
    $orderId = (int) $pdo->lastInsertId();
    $pdo->prepare('UPDATE ' . dg_prefix() . 'orders SET client_order_id = ? WHERE id = ?')
        ->execute(array('DG-' . $orderId, $orderId));
    if ($walletPaid) {
        $pdo->prepare('UPDATE ' . dg_prefix() . 'users SET balance = balance - ?, spend_points = spend_points + ?, lifetime_spend = lifetime_spend + ? WHERE id = ?')
            ->execute(array($total, (int) round($total), $total, (int) $user['id']));
    }
    $pdo->commit();
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    dg_fail(500, 'Order save failed — একটু পরে আবার চেষ্টা করুন।');
}

dg_bump_rev('ledger');

// Voucher usage counter lives in the stored content (server-side counter).
if ($manualVoucher && isset($manualVoucher['code'])) {
    $touched = false;
    foreach (($content['vouchers'] ?? array()) as $idx => $item) {
        if (is_array($item) && isset($item['code']) && strtoupper($item['code']) === strtoupper($manualVoucher['code'])) {
            $content['vouchers'][$idx]['used'] = (int) (isset($item['used']) ? $item['used'] : 0) + 1;
            $touched = true;
        }
    }
    if ($touched) {
        dg_save_content($content);
    }
}

$row = null;
$st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'orders WHERE id = ?');
$st->execute(array($orderId));
$row = $st->fetch(PDO::FETCH_ASSOC);

// Auto Topup: wallet orders for mapped variations are forwarded right away;
// the provider's webhook later flips the status (success/error + refund).
$forward = null;
if ($willAuto && !$gateway && $row) {
    $forward = dg_forward_to_provider($row, $content, true);
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'orders WHERE id = ?');
    $st->execute(array($orderId));
    $row = $st->fetch(PDO::FETCH_ASSOC);
}

// Telegram: the admin gets "NEW ORDER RECEIVED" the moment the order lands.
if ($row) {
    dg_telegram_notify($site, dg_msg_order($row, $site));
}

$st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ?');
$st->execute(array((int) $user['id']));
$freshUser = $st->fetch(PDO::FETCH_ASSOC);

dg_json_out(200, array(
    'ok' => true,
    'order' => $row ? dg_order_row($row) : null,
    'me' => $freshUser ? dg_me_payload($freshUser) : null,
    'forward' => is_array($forward) && isset($forward['skipped']) ? null : $forward,
));
