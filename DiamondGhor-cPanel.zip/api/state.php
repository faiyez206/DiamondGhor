<?php
/**
 * DiamondGhor API — storefront state.
 * GET /api/state.php?c={contentRev}&m={meRev}
 * Returns the public content (secrets stripped), the session user's profile +
 * finances, their own ledger rows, the recent-orders feed and the leaderboard.
 * When nothing changed for this caller the payload is served anyway (cheap),
 * but the client uses c/m to skip re-rendering.
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    dg_fail(405, 'GET only');
}

dg_rate_limit('state', 240, 60);

$pdo = dg_db();
$content = dg_content();
$cRev = (int) dg_meta_get('rev_c', '0');
$user = dg_current_user();

$me = null;
$my = array();
$mRev = 'guest';

if ($user) {
    $me = dg_me_payload($user);
    $uid = (int) $user['id'];
    $email = $user['email'];

    $orders = array();
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'orders WHERE user_id = ? ORDER BY id DESC LIMIT 100');
    $st->execute(array($uid));
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $orders[] = dg_order_row($row);
    }

    $deposits = array();
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'deposits WHERE user_id = ? ORDER BY id DESC LIMIT 100');
    $st->execute(array($uid));
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $deposits[] = dg_deposit_row($row);
    }

    $spinLogs = array();
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'spin_logs WHERE user_id = ? ORDER BY id DESC LIMIT 30');
    $st->execute(array($uid));
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $spinLogs[] = dg_spin_log_row($row);
    }

    $referrals = array();
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'referrals WHERE referred_email = ? OR referrer_user_id = ? ORDER BY id DESC LIMIT 50');
    $st->execute(array($email, $uid));
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $referrals[] = dg_referral_row($row);
    }

    $conversions = array();
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'coin_conversions WHERE user_id = ? ORDER BY id DESC LIMIT 50');
    $st->execute(array($uid));
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $conversions[] = dg_coin_row($row);
    }

    $balanceLogs = array();
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'balance_logs WHERE user_id = ? ORDER BY id DESC LIMIT 30');
    $st->execute(array($uid));
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $balanceLogs[] = dg_balance_log_row($row);
    }

    $my = array(
        'orders' => $orders,
        'deposits' => $deposits,
        'spinLogs' => $spinLogs,
        'referrals' => $referrals,
        'coinConversions' => $conversions,
        'balanceLogs' => $balanceLogs,
    );

    // Cheap freshness fingerprint of everything that belongs to this user.
    // Positional placeholders — native MySQL prepares reject reused names.
    $st = $pdo->prepare('SELECT
        (SELECT COUNT(*) FROM ' . dg_prefix() . 'orders WHERE user_id = ?),
        (SELECT COALESCE(MAX(updated_at), "x") FROM ' . dg_prefix() . 'orders WHERE user_id = ?),
        (SELECT COUNT(*) FROM ' . dg_prefix() . 'deposits WHERE user_id = ?),
        (SELECT COALESCE(MAX(updated_at), "x") FROM ' . dg_prefix() . 'deposits WHERE user_id = ?),
        (SELECT COUNT(*) FROM ' . dg_prefix() . 'spin_logs WHERE user_id = ?),
        (SELECT COUNT(*) FROM ' . dg_prefix() . 'coin_conversions WHERE user_id = ?),
        (SELECT COUNT(*) FROM ' . dg_prefix() . 'redeemed_codes WHERE user_id = ?),
        (SELECT COUNT(*) FROM ' . dg_prefix() . 'referrals WHERE referred_email = ? OR referrer_user_id = ?),
        (SELECT CONCAT(balance, ":", coins, ":", premium, ":", spend_points) FROM ' . dg_prefix() . 'users WHERE id = ?)');
    $st->execute(array($uid, $uid, $uid, $uid, $uid, $uid, $uid, $email, $uid, $uid));
    $mRev = md5(implode('|', $st->fetch(PDO::FETCH_NUM)));
}

// Recent orders feed (public, sanitized — no player ids / emails / refs).
$recent = array();
$st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'orders ORDER BY id DESC LIMIT 6');
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $recent[] = dg_order_public_row($row);
}

// Leaderboard: server-side ranking from spend points (1 point per ৳1 spent).
$leaderboard = array();
$st = $pdo->query('SELECT name, spend_points FROM ' . dg_prefix() . 'users WHERE spend_points > 0 ORDER BY spend_points DESC LIMIT 100');
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $points = (int) $row['spend_points'];
    $leaderboard[] = array(
        'name' => $row['name'] !== '' ? $row['name'] : 'Player',
        'points' => $points,
        'rank' => dg_rank_for($points),
    );
}

dg_json_out(200, array(
    'ok' => true,
    'c' => $cRev,
    'm' => $mRev,
    'csrf' => dg_csrf_token(),
    'content' => dg_public_content($content),
    'me' => $me,
    'my' => $my,
    'recentOrders' => $recent,
    'leaderboard' => $leaderboard,
    'serverTime' => date('c'),
));
