<?php
/**
 * DiamondGhor — one-time web installer (2 minutes).
 *
 * 1. Checks the server requirements (PHP 7.4+, PDO MySQL, cURL).
 * 2. Creates the MySQL tables from schema.sql.
 * 3. Writes dg-config.php OUTSIDE public_html (parent of the document root),
 *    with a deny-protected in-webroot fallback if the parent is not writable.
 * 4. Seeds the storefront content (seeds.json) and creates the admin account.
 * 5. Locks itself (dg-install.lock next to the config file).
 *
 * After setup the whole /api works with no further configuration.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
header('X-Content-Type-Options: nosniff');

function dg_out_json($status, $payload) {
    http_response_code((int) $status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function dg_req_checks() {
    $pdoDrivers = class_exists('PDO') && in_array('mysql', PDO::getAvailableDrivers(), true);
    return array(
        'php' => array('ok' => version_compare(PHP_VERSION, '7.4.0', '>='), 'value' => PHP_VERSION),
        'pdoMysql' => array('ok' => $pdoDrivers, 'value' => $pdoDrivers ? 'yes' : 'missing'),
        'curl' => array('ok' => function_exists('curl_init'), 'value' => function_exists('curl_init') ? 'yes' : 'fallback will be used'),
        'json' => array('ok' => function_exists('json_encode'), 'value' => 'yes'),
    );
}

function dg_docroot() {
    $docroot = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '/') : '';
    if (!$docroot) {
        // php -S dev server or unusual setups: derive from this file
        // .../public_html/api/install/index.php → .../public_html
        $docroot = dirname(__DIR__, 1);
    }
    return $docroot;
}

function dg_config_candidates() {
    $candidates = array();
    $docroot = dg_docroot();
    $candidates[] = dirname($docroot) . '/dg-config.php';
    $candidates[] = dirname(__DIR__, 2) . '/dg-config.php';
    $candidates[] = __DIR__ . '/config.php'; // in-webroot fallback (denied via .htaccess)
    return $candidates;
}

function dg_existing_config() {
    foreach (dg_config_candidates() as $path) {
        if ($path && is_file($path)) {
            return $path;
        }
    }
    return '';
}

function dg_lock_path() {
    $config = dg_existing_config();
    if ($config !== '') {
        return dirname($config) . '/dg-install.lock';
    }
    return dirname(dg_docroot()) . '/dg-install.lock';
}

function dg_installed() {
    $lock = dg_lock_path();
    if (is_file($lock)) {
        return true;
    }
    $config = dg_existing_config();
    if ($config === '') {
        return false;
    }
    require $config;
    if (!defined('DG_DB_HOST')) {
        return false;
    }
    try {
        $dsn = 'mysql:host=' . DG_DB_HOST . ';dbname=' . DG_DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DG_DB_USER, DG_DB_PASS);
        $prefix = defined('DG_DB_PREFIX') ? DG_DB_PREFIX : 'dg_';
        $st = $pdo->prepare('SHOW TABLES LIKE ?');
        $st->execute(array($prefix . 'users'));
        return (bool) $st->fetch();
    } catch (Exception $e) {
        return false;
    }
}

function dg_config_template($f) {
    $q = function ($v) { return var_export((string) $v, true); };
    return "<?php\n"
        . "// DiamondGhor configuration — KEEP THIS FILE OUTSIDE public_html.\n"
        . "// Written by /api/install/ on " . date('c') . "\n\n"
        . "define('DG_DB_HOST', " . $q($f['host']) . ");\n"
        . "define('DG_DB_PORT', " . $q(isset($f['port']) && $f['port'] !== '' ? $f['port'] : '') . ");\n"
        . "define('DG_DB_NAME', " . $q($f['name']) . ");\n"
        . "define('DG_DB_USER', " . $q($f['user']) . ");\n"
        . "define('DG_DB_PASS', " . $q($f['pass']) . ");\n"
        . "define('DG_DB_PREFIX', " . $q($f['prefix'] !== '' ? $f['prefix'] : 'dg_') . ");\n"
        . "define('DG_TIMEZONE', " . $q($f['tz'] !== '' ? $f['tz'] : 'Asia/Dhaka') . ");\n"
        . "define('DG_SESSION_NAME', 'DGHSESS');\n";
}

function dg_write_config($template) {
    // Prefer a path OUTSIDE the document root; fall back to the protected
    // api/ folder when no parent directory is writable.
    foreach (dg_config_candidates() as $path) {
        $dir = dirname($path);
        if (!is_dir($dir) || !is_writable($dir)) {
            continue;
        }
        if (@file_put_contents($path, $template) !== false) {
            @chmod($path, 0640);
            return array('path' => $path, 'outsideDocroot' => strpos($path, dg_docroot()) !== 0);
        }
    }
    return null;
}

$action = isset($_REQUEST['action']) ? (string) $_REQUEST['action'] : '';
$already = dg_installed();

if ($action === 'status') {
    $config = dg_existing_config();
    dg_out_json(200, array(
        'ok' => true,
        'installed' => $already,
        'configFound' => $config !== '',
        'configPath' => $config,
        'checks' => dg_req_checks(),
    ));
}

if ($action === 'test') {
    $f = array(
        'host' => trim((string) ($_POST['host'] ?? 'localhost')),
        'port' => trim((string) ($_POST['port'] ?? '')),
        'name' => trim((string) ($_POST['name'] ?? '')),
        'user' => trim((string) ($_POST['user'] ?? '')),
        'pass' => (string) ($_POST['pass'] ?? ''),
        'prefix' => preg_replace('/[^a-z0-9_]/i', '', trim((string) ($_POST['prefix'] ?? 'dg_'))),
        'tz' => trim((string) ($_POST['tz'] ?? 'Asia/Dhaka')),
    );
    try {
        $dsn = 'mysql:host=' . $f['host'] . ($f['port'] !== '' ? ';port=' . $f['port'] : '') . ';charset=utf8mb4';
        $pdo = new PDO($dsn, $f['user'], $f['pass'], array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 8));
        $version = $pdo->query('SELECT VERSION()')->fetchColumn();
        try {
            $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . str_replace('`', '', $f['name']) . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        } catch (Exception $e) {
            // cPanel users cannot create databases — the DB must already exist.
        }
        $pdo->exec('USE `' . str_replace('`', '', $f['name']) . '`');
        dg_out_json(200, array('ok' => true, 'version' => $version));
    } catch (Exception $e) {
        dg_out_json(400, array('ok' => false, 'error' => $e->getMessage()));
    }
}

if ($action === 'install') {
    if ($already) {
        dg_out_json(409, array('ok' => false, 'error' => 'DiamondGhor is already installed. Delete the lock file to reinstall: ' . dg_lock_path()));
    }
    $f = array(
        'host' => trim((string) ($_POST['host'] ?? 'localhost')),
        'port' => trim((string) ($_POST['port'] ?? '')),
        'name' => trim((string) ($_POST['name'] ?? '')),
        'user' => trim((string) ($_POST['user'] ?? '')),
        'pass' => (string) ($_POST['pass'] ?? ''),
        'prefix' => preg_replace('/[^a-z0-9_]/i', '', trim((string) ($_POST['prefix'] ?? 'dg_'))) ?: 'dg_',
        'tz' => trim((string) ($_POST['tz'] ?? 'Asia/Dhaka')),
    );
    $adminName = trim((string) ($_POST['adminName'] ?? 'Admin'));
    $adminEmail = strtolower(trim((string) ($_POST['adminEmail'] ?? '')));
    $adminPass = (string) ($_POST['adminPass'] ?? '');
    if ($f['name'] === '' || $f['user'] === '') {
        dg_out_json(400, array('ok' => false, 'error' => 'Database name and user are required.'));
    }
    if (!filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) {
        dg_out_json(400, array('ok' => false, 'error' => 'Admin email is not valid.'));
    }
    if (strlen($adminPass) < 6) {
        dg_out_json(400, array('ok' => false, 'error' => 'Admin password must be at least 6 characters.'));
    }
    try {
        $dsn = 'mysql:host=' . $f['host'] . ($f['port'] !== '' ? ';port=' . $f['port'] : '') . ';dbname=' . $f['name'] . ';charset=utf8mb4';
        $pdo = new PDO($dsn, $f['user'], $f['pass'], array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 10));
    } catch (Exception $e) {
        dg_out_json(400, array('ok' => false, 'error' => 'Database connect failed: ' . $e->getMessage()));
    }

    // 1. schema
    $schema = @file_get_contents(__DIR__ . '/schema.sql');
    if (!$schema) {
        dg_out_json(500, array('ok' => false, 'error' => 'schema.sql missing in api/install/ — re-upload the api folder.'));
    }
    $schema = str_replace('{prefix}', $f['prefix'], $schema);
    try {
        $pdo->exec($schema);
    } catch (Exception $e) {
        dg_out_json(500, array('ok' => false, 'error' => 'Table creation failed: ' . $e->getMessage()));
    }

    // 2. seed content
    $seedsRaw = @file_get_contents(__DIR__ . '/seeds.json');
    if (!$seedsRaw) {
        dg_out_json(500, array('ok' => false, 'error' => 'seeds.json missing in api/install/ — re-upload the api folder.'));
    }
    $st = $pdo->prepare('INSERT INTO ' . $f['prefix'] . 'settings (k, v) VALUES ("content", ?) ON DUPLICATE KEY UPDATE v = VALUES(v)');
    $st->execute(array($seedsRaw));
    $pdo->prepare('INSERT INTO ' . $f['prefix'] . 'meta (k, v) VALUES ("rev_c", "1") ON DUPLICATE KEY UPDATE v = VALUES(v)')->execute();
    $pdo->prepare('INSERT INTO ' . $f['prefix'] . 'meta (k, v) VALUES ("rev_a", "1") ON DUPLICATE KEY UPDATE v = VALUES(v)')->execute();

    // 3. admin account
    $pin = str_pad((string) random_int(0, 9999), 4, '0', STR_PAD_LEFT);
    $st = $pdo->prepare('SELECT id FROM ' . $f['prefix'] . 'users WHERE email = ?');
    $st->execute(array($adminEmail));
    if ($st->fetch()) {
        dg_out_json(400, array('ok' => false, 'error' => 'That email already exists in the users table.'));
    }
    $st = $pdo->prepare('INSERT INTO ' . $f['prefix'] . 'users (email, password_hash, name, phone, provider, role, verified, support_pin, level, rank_name, joined, status) VALUES (?, ?, ?, "", "password", "admin", 1, ?, 1, "Grand Master", ?, "Active")');
    $st->execute(array($adminEmail, password_hash($adminPass, PASSWORD_DEFAULT), $adminName !== '' ? $adminName : 'Admin', $pin, date('Y-m-d')));

    // 4. config file (outside the web root when possible)
    $written = dg_write_config(dg_config_template($f));
    if (!$written) {
        dg_out_json(500, array(
            'ok' => false,
            'manual' => true,
            'error' => 'Could not write the config file automatically. Create dg-config.php yourself with the content below, then click Verify.',
            'config' => dg_config_template($f),
            'locations' => dg_config_candidates(),
        ));
    }

    // 5. lock
    @file_put_contents(dirname($written['path']) . '/dg-install.lock', date('c'));

    dg_out_json(200, array(
        'ok' => true,
        'configPath' => $written['path'],
        'outsideDocroot' => $written['outsideDocroot'],
        'adminEmail' => $adminEmail,
        'supportPin' => $pin,
    ));
}

if ($action === 'verify') {
    dg_out_json(200, array('ok' => true, 'installed' => dg_installed(), 'configPath' => dg_existing_config()));
}

// ------------------------------------------------------------ HTML wizard
$checks = dg_req_checks();
$allOk = true;
foreach ($checks as $check) {
    if (!$check['ok']) {
        $allOk = false;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>DiamondGhor — Install</title>
<style>
  * { box-sizing: border-box; margin: 0; }
  body { font-family: 'Segoe UI', system-ui, sans-serif; background: #12071d; color: #f4ecff; min-height: 100vh; display: flex; justify-content: center; padding: 24px 14px; }
  .card { width: 100%; max-width: 620px; background: #1d0b2e; border: 1px solid #3a1c54; border-radius: 18px; padding: 28px 24px; }
  h1 { font-size: 22px; margin-bottom: 4px; color: #ff5c95; }
  .sub { color: #b9a3d4; font-size: 13px; margin-bottom: 20px; }
  .checks { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 20px; }
  .check { font-size: 12px; padding: 6px 10px; border-radius: 999px; background: #2a1240; border: 1px solid #43215f; }
  .check.ok { color: #7ef0b2; }
  .check.bad { color: #ff8fa8; }
  label { display: block; font-size: 12px; color: #cdb9e8; margin: 12px 0 4px; }
  input { width: 100%; padding: 10px 12px; border-radius: 10px; border: 1px solid #43215f; background: #160925; color: #fff; font-size: 14px; }
  .row2 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  button { width: 100%; margin-top: 18px; padding: 12px; border: 0; border-radius: 10px; background: linear-gradient(135deg, #ff2e63, #ff5c95); color: #fff; font-size: 15px; font-weight: 700; cursor: pointer; }
  button.ghost { background: #2a1240; color: #d9c8f2; margin-top: 10px; }
  button:disabled { opacity: .5; cursor: wait; }
  .msg { margin-top: 14px; font-size: 13px; border-radius: 10px; padding: 10px 12px; display: none; white-space: pre-wrap; word-break: break-word; }
  .msg.err { display: block; background: #3d1023; color: #ffb3c6; }
  .msg.good { display: block; background: #10331f; color: #8ff0bd; }
  h3 { font-size: 14px; margin: 18px 0 2px; color: #e3d0ff; }
  textarea { width: 100%; height: 180px; margin-top: 10px; font-family: monospace; font-size: 11px; background: #160925; color: #9fe8c0; border: 1px solid #43215f; border-radius: 10px; padding: 10px; }
  .done { text-align: center; padding: 30px 0 10px; }
  .done .big { font-size: 42px; }
  a { color: #ff7fa8; }
</style>
</head>
<body>
  <div class="card">
    <h1>💎 DiamondGhor — Setup</h1>
    <p class="sub">PHP + MySQL backend for your cPanel hosting. Ektu time lage — 3 step.</p>
    <div class="checks" id="checks"></div>
    <div id="wizard">
      <h3>1 · MySQL database (cPanel → MySQL Databases theke banano)</h3>
      <label>DB Host</label>
      <input id="host" value="localhost" />
      <div class="row2">
        <div><label>DB Name</label><input id="name" placeholder="cpaneluser_diamond" /></div>
        <div><label>DB User</label><input id="user" placeholder="cpaneluser_dg" /></div>
      </div>
      <label>DB Password</label>
      <input id="pass" type="password" />
      <div class="row2">
        <div><label>Table prefix</label><input id="prefix" value="dg_" /></div>
        <div><label>Timezone</label><input id="tz" value="Asia/Dhaka" /></div>
      </div>
      <h3>2 · Admin account</h3>
      <label>Admin name</label>
      <input id="adminName" value="Admin" />
      <label>Admin email (login)</label>
      <input id="adminEmail" type="email" placeholder="admin@gmail.com" />
      <label>Admin password (6+ characters)</label>
      <input id="adminPass" type="password" />
      <button id="go">Install DiamondGhor</button>
      <button class="ghost" id="test" type="button">Test database connection</button>
      <div class="msg" id="msg"></div>
      <div id="manual" style="display:none">
        <h3>Manual config — create this file, then Verify</h3>
        <textarea id="cfg" readonly></textarea>
        <button class="ghost" id="verify" type="button">Verify after creating the file</button>
      </div>
    </div>
    <div id="done" class="done" style="display:none">
      <div class="big">✅</div>
      <h3>DiamondGhor installed!</h3>
      <p class="sub" id="doneMsg"></p>
      <a href="/">Open your site →</a>
      <p class="sub" style="margin-top:12px">Ekhon ei installer r config file ar kono dorkar nei. Admin panel: <a href="/admin">/admin</a></p>
    </div>
  </div>
<script>
  const $ = (id) => document.getElementById(id);
  const msg = (text, bad) => { const el = $('msg'); el.className = 'msg ' + (bad ? 'err' : 'good'); el.textContent = text; };
  fetch('?action=status').then(r => r.json()).then(s => {
    const wrap = $('checks');
    Object.entries(s.checks).forEach(([key, check]) => {
      const span = document.createElement('span');
      span.className = 'check ' + (check.ok ? 'ok' : 'bad');
      span.textContent = (check.ok ? '✓ ' : '✗ ') + key + ' (' + check.value + ')';
      wrap.appendChild(span);
    });
    if (s.installed) {
      $('wizard').style.display = 'none';
      $('done').style.display = 'block';
      $('doneMsg').textContent = 'Config: ' + (s.configPath || 'dg-config.php') + ' — already installed.';
    }
  }).catch(() => msg('status check failed — refresh kore dekho', true));

  async function post(action) {
    const fields = ['host', 'port', 'name', 'user', 'pass', 'prefix', 'tz', 'adminName', 'adminEmail', 'adminPass'];
    const body = new URLSearchParams({ action });
    fields.forEach((f) => { const el = $(f); if (el) body.append(f, el.value); });
    const response = await fetch('', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body.toString() });
    return response.json();
  }

  $('test').onclick = async () => {
    $('test').disabled = true;
    try {
      const data = await post('test');
      if (data.ok) msg('Database OK — MySQL ' + data.version, false);
      else msg(data.error, true);
    } catch (e) { msg('test failed: ' + e.message, true); }
    $('test').disabled = false;
  };

  $('go').onclick = async () => {
    $('go').disabled = true;
    try {
      const data = await post('install');
      if (data.ok) {
        $('wizard').style.display = 'none';
        $('done').style.display = 'block';
        $('doneMsg').textContent = 'Config file: ' + data.configPath + (data.outsideDocroot ? ' (outside public_html ✓)' : ' (inside api/ — protected by .htaccess)') + ' · Support PIN: DG' + data.supportPin;
      } else if (data.manual) {
        msg(data.error, true);
        $('manual').style.display = 'block';
        $('cfg').value = data.config;
      } else {
        msg(data.error, true);
      }
    } catch (e) { msg('install failed: ' + e.message, true); }
    $('go').disabled = false;
  };

  $('verify').onclick = async () => {
    const data = await post('verify').then(r => r.json()).catch(() => null);
    if (data && data.installed) {
      $('wizard').style.display = 'none';
      $('done').style.display = 'block';
      $('doneMsg').textContent = 'Config file: ' + data.configPath;
    } else {
      msg('Ekhono config file khuje pai nai — thik jaygay banaychen kina check korun.', true);
    }
  };
</script>
</body>
</html>
