<?php
/**
 * DiamondGhor API — wallet add-money requests.
 * POST /api/deposits.php  { amount, method, sender, trxId, gateway }
 * Creates a Pending deposit; the balance is credited ONLY when the admin
 * approves it (server-side credit + audit row + VIP check + Telegram).
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dg_fail(405, 'POST only');
}

$pdo = dg_db();
$user = dg_require_user();
$body = dg_body();
dg_check_csrf($body);
dg_rate_limit('deposits', 20, 3600);

$content = dg_content();
$site = isset($content['site']) && is_array($content['site']) ? $content['site'] : array();

$value = (float) dg_field($body, 'amount', 0);
$method = (string) dg_field($body, 'method', '');
$sender = preg_replace('/\D/', '', (string) dg_field($body, 'sender', ''));
$trxId = strtoupper(trim((string) dg_field($body, 'trxId', '')));
$gateway = (bool) dg_field($body, 'gateway', false);

$minAmount = isset($site['minAmount']) && (float) $site['minAmount'] > 0 ? (float) $site['minAmount'] : 10;
$maxAmount = isset($site['maxAmount']) && (float) $site['maxAmount'] > 0 ? (float) $site['maxAmount'] : 50000;
if ($value <= 0 || $value < $minAmount) {
    dg_fail(400, 'কমপক্ষে ৳' . (int) $minAmount . ' ডিপোজিট করুন।');
}
if ($value > $maxAmount) {
    dg_fail(400, 'সর্বোচ্চ ৳' . (int) $maxAmount . ' ডিপোজিট করা যাবে।');
}
if (!$gateway) {
    if (!preg_match('/^01[3-9]\d{8}$/', $sender)) {
        dg_fail(400, 'যে নাম্বার থেকে টাকা পাঠিয়েছেন সেটি দিন।');
    }
    if (strlen($trxId) < 4) {
        dg_fail(400, 'সঠিক ট্রানজেকশন আইডি দিন।');
    }
}
if ($trxId !== '' && dg_trx_id_used($trxId)) {
    dg_fail(400, 'এই ট্রানজেকশন আইডি আগে ব্যবহার হয়েছে।');
}
if ($method === '') {
    if ($gateway) {
        $method = isset($site['paymentBrand']) && $site['paymentBrand'] !== '' ? $site['paymentBrand'] : 'Gateway';
    } else {
        $method = 'bKash';
    }
}

$st = $pdo->prepare('INSERT INTO ' . dg_prefix() . 'deposits (user_id, user_email, user_name, method, amount, sender, trx_id, gateway, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, "Pending")');
$st->execute(array((int) $user['id'], $user['email'], $user['name'], $method, $value, $sender, $trxId, $gateway ? 1 : 0));
$depositId = (int) $pdo->lastInsertId();
dg_bump_rev('ledger');

$st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'deposits WHERE id = ?');
$st->execute(array($depositId));
$row = $st->fetch(PDO::FETCH_ASSOC);

// Manual deposits already carry sender + TrxID — ping the admin right away.
// Gateway deposits ping later, when the customer submits the TrxID.
if (!$gateway && $row) {
    dg_telegram_notify($site, dg_msg_deposit($row, 'usr-' . (int) $user['id'], $site));
}

dg_json_out(200, array('ok' => true, 'deposit' => $row ? dg_deposit_row($row) : null));
