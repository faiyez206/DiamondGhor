<?php
/**
 * DiamondGhor API — authentication.
 * POST /api/auth.php  { action: login | register | google | logout | session }
 * PHP sessions (httponly cookie), password_hash, login throttling, rate limits.
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dg_fail(405, 'POST only');
}

$pdo = dg_db();
$body = dg_body();
$action = (string) dg_field($body, 'action', '');

function dg_site_of($content) {
    return isset($content['site']) && is_array($content['site']) ? $content['site'] : array();
}

// --------------------------------------------------------------- logout
if ($action === 'logout') {
    dg_check_csrf($body, true);
    $_SESSION = array();
    @session_destroy();
    dg_json_out(200, array('ok' => true));
}

// --------------------------------------------------------------- session probe
if ($action === 'session') {
    $user = dg_current_user();
    dg_json_out(200, array(
        'ok' => true,
        'loggedIn' => $user ? true : false,
        'isAdmin' => $user && $user['role'] === 'admin',
        'me' => $user ? dg_me_payload($user) : null,
        'csrf' => dg_csrf_token(),
    ));
}

// --------------------------------------------------------------- login
if ($action === 'login') {
    dg_rate_limit('login', 12, 600);
    dg_check_csrf($body, true);
    $email = strtolower((string) dg_field($body, 'email', ''));
    $password = (string) dg_field($body, 'password', '');
    if (!preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/', $email)) {
        dg_fail(400, 'Enter a valid email address');
    }
    if ($password === '') {
        dg_fail(400, 'Enter your password');
    }
    $locked = dg_login_locked($email);
    if ($locked > 0) {
        dg_fail(429, 'অনেকবার ভুল চেষ্টা হয়েছে — ' . (int) ceil($locked / 60) . ' মিনিট পরে আবার চেষ্টা করুন।');
    }
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE email = ? LIMIT 1');
    $st->execute(array($email));
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row || empty($row['password_hash']) || !password_verify($password, $row['password_hash'])) {
        dg_login_fail($email);
        if ($row && $row['role'] === 'admin') {
            $site = dg_site_of(dg_content());
            dg_telegram_notify($site, dg_msg_admin_login(array('email' => $email), false));
        }
        dg_fail(401, 'Email or password is incorrect.');
    }
    if ($row['status'] !== 'Active') {
        dg_fail(403, 'এই একাউন্টটি ব্লক করা হয়েছে। সাপোর্টে যোগাযোগ করুন।');
    }
    if (password_needs_rehash($row['password_hash'], PASSWORD_DEFAULT)) {
        $pdo->prepare('UPDATE ' . dg_prefix() . 'users SET password_hash = ? WHERE id = ?')
            ->execute(array(password_hash($password, PASSWORD_DEFAULT), (int) $row['id']));
    }
    dg_login_clear($email);
    dg_login_session($row);
    if ($row['role'] === 'admin') {
        dg_admin_log($row, 'admin.login', 'Admin signed in from ' . dg_client_ip());
        $site = dg_site_of(dg_content());
        dg_telegram_notify($site, dg_msg_admin_login($row, true));
    }
    dg_json_out(200, array(
        'ok' => true,
        'account' => dg_profile($row),
        'isAdmin' => $row['role'] === 'admin',
        'me' => dg_me_payload($row),
        'csrf' => dg_csrf_token(),
    ));
}

// --------------------------------------------------------------- register
if ($action === 'register') {
    dg_rate_limit('register', 8, 3600);
    dg_check_csrf($body, true);
    $name = trim((string) dg_field($body, 'name', ''));
    $email = strtolower(trim((string) dg_field($body, 'email', '')));
    $phone = preg_replace('/\D/', '', (string) dg_field($body, 'phone', ''));
    if (substr($phone, 0, 3) === '880') {
        $phone = '0' . substr($phone, 3);
    }
    $password = (string) dg_field($body, 'password', '');
    $referralCode = strtoupper(trim((string) dg_field($body, 'referralCode', '')));
    if ($name === '') {
        dg_fail(400, 'Enter your full name');
    }
    if (!preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/', $email)) {
        dg_fail(400, 'Enter a valid email address');
    }
    if (!preg_match('/^01[3-9]\d{8}$/', $phone)) {
        dg_fail(400, 'Enter a valid phone number');
    }
    if (strlen($password) < 6) {
        dg_fail(400, 'Password must be at least 6 characters');
    }
    $st = $pdo->prepare('SELECT id FROM ' . dg_prefix() . 'users WHERE email = ?');
    $st->execute(array($email));
    if ($st->fetch()) {
        dg_fail(409, 'এই ইমেইলে একটি একাউন্ট আছে — লগইন করুন।');
    }
    $site = dg_site_of(dg_content());
    $pin = '';
    for ($i = 0; $i < 25; $i++) {
        $candidate = str_pad((string) random_int(0, 9999), 4, '0', STR_PAD_LEFT);
        $chk = $pdo->prepare('SELECT id FROM ' . dg_prefix() . 'users WHERE support_pin = ?');
        $chk->execute(array($candidate));
        if (!$chk->fetch()) {
            $pin = $candidate;
            break;
        }
    }
    if ($pin === '') {
        $pin = (string) random_int(1000, 9999);
    }
    $st = $pdo->prepare('INSERT INTO ' . dg_prefix() . 'users (email, password_hash, name, phone, provider, verified, support_pin, level, rank_name, joined, status) VALUES (?, ?, ?, ?, "password", 1, ?, 1, "Bronze", ?, "Active")');
    $st->execute(array($email, password_hash($password, PASSWORD_DEFAULT), $name, $phone, $pin, date('Y-m-d')));
    $newId = (int) $pdo->lastInsertId();
    // A referral code from the signup link creates a Pending row the admin
    // approves; approving it credits the code owner's wallet (server-side).
    if ($referralCode !== '') {
        $reward = isset($site['referralReward']) ? (float) $site['referralReward'] : 0;
        $referrer = null;
        if (preg_match('/^DG(\d{4})$/i', $referralCode, $m)) {
            $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE support_pin = ? LIMIT 1');
            $st->execute(array($m[1]));
            $referrer = $st->fetch(PDO::FETCH_ASSOC);
        }
        $st = $pdo->prepare('INSERT INTO ' . dg_prefix() . 'referrals (referrer_user_id, code, code_owner, referred_email, reward, status) VALUES (?, ?, ?, ?, ?, "Pending")');
        $st->execute(array(
            $referrer ? (int) $referrer['id'] : null,
            substr($referralCode, 0, 64),
            $referrer ? $referrer['name'] : '',
            $email,
            $reward,
        ));
        dg_bump_rev('ledger');
    }
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ?');
    $st->execute(array($newId));
    $row = $st->fetch(PDO::FETCH_ASSOC);
    dg_login_session($row);
    dg_json_out(200, array(
        'ok' => true,
        'account' => dg_profile($row),
        'isAdmin' => false,
        'me' => dg_me_payload($row),
        'csrf' => dg_csrf_token(),
    ));
}

// --------------------------------------------------------------- google
if ($action === 'google') {
    dg_rate_limit('google', 15, 600);
    dg_check_csrf($body, true);
    $code = (string) dg_field($body, 'code', '');
    $redirectUri = (string) dg_field($body, 'redirectUri', '');
    $codeVerifier = (string) dg_field($body, 'codeVerifier', '');
    if ($code === '' || $redirectUri === '') {
        dg_fail(400, 'Missing code/redirectUri.');
    }
    $site = dg_site_of(dg_content());
    $clientId = isset($site['googleClientId']) ? trim((string) $site['googleClientId']) : '';
    // The client secret lives ONLY in the server-side settings now — the
    // browser never sends it (the old client-side exchange is removed).
    $clientSecret = isset($site['googleClientSecret']) ? trim((string) $site['googleClientSecret']) : '';
    if ($clientId === '' || $clientSecret === '') {
        dg_fail(400, 'Google login ekhono setup hoyni — Admin → Settings → Google Login e Client ID ar Secret save korun.');
    }
    $post = array(
        'code' => $code,
        'client_id' => $clientId,
        'client_secret' => $clientSecret,
        'redirect_uri' => $redirectUri,
        'grant_type' => 'authorization_code',
    );
    if ($codeVerifier !== '') {
        $post['code_verifier'] = $codeVerifier;
    }
    $res = false;
    if (function_exists('curl_init')) {
        $ch = curl_init('https://oauth2.googleapis.com/token');
        curl_setopt_array($ch, array(
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($post),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
        ));
        $res = curl_exec($ch);
        if ($res === false) {
            $err = curl_error($ch);
            curl_close($ch);
            dg_fail(502, 'Google request failed: ' . $err);
        }
        curl_close($ch);
    } else {
        $ctx = stream_context_create(array('http' => array(
            'method' => 'POST',
            'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => http_build_query($post),
            'timeout' => 20,
            'ignore_errors' => true,
        )));
        $res = @file_get_contents('https://oauth2.googleapis.com/token', false, $ctx);
        if ($res === false) {
            dg_fail(502, 'Google request failed (cURL missing and allow_url_fopen disabled).');
        }
    }
    $tokenData = json_decode((string) $res, true);
    if (!is_array($tokenData) || empty($tokenData['id_token'])) {
        $error = 'Google token exchange failed';
        if (isset($tokenData['error_description']) && is_string($tokenData['error_description']) && $tokenData['error_description'] !== '') {
            $error = $tokenData['error_description'];
        } elseif (isset($tokenData['error']) && is_string($tokenData['error']) && $tokenData['error'] !== '') {
            $error = $tokenData['error'];
        }
        dg_fail(400, $error);
    }
    $parts = explode('.', $tokenData['id_token']);
    if (count($parts) < 2) {
        dg_fail(400, 'Could not read the Google profile.');
    }
    $payload = json_decode(base64_decode(strtr($parts[1], '-_', '+/')), true);
    if (!is_array($payload) || empty($payload['email'])) {
        dg_fail(400, 'Could not read the Google profile.');
    }
    $email = strtolower((string) $payload['email']);
    $gName = isset($payload['name']) && is_string($payload['name']) && $payload['name'] !== '' ? $payload['name'] : $email;
    $picture = isset($payload['picture']) && is_string($payload['picture']) ? $payload['picture'] : '';
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE email = ? LIMIT 1');
    $st->execute(array($email));
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        $pdo->prepare('UPDATE ' . dg_prefix() . 'users SET picture = ?, name = CASE WHEN name = "" OR name IS NULL THEN ? ELSE name END, verified = 1 WHERE id = ?')
            ->execute(array($picture, $gName, (int) $row['id']));
        $row['picture'] = $picture;
    } else {
        $pin = '';
        for ($i = 0; $i < 25; $i++) {
            $candidate = str_pad((string) random_int(0, 9999), 4, '0', STR_PAD_LEFT);
            $chk = $pdo->prepare('SELECT id FROM ' . dg_prefix() . 'users WHERE support_pin = ?');
            $chk->execute(array($candidate));
            if (!$chk->fetch()) {
                $pin = $candidate;
                break;
            }
        }
        if ($pin === '') {
            $pin = (string) random_int(1000, 9999);
        }
        $pdo->prepare('INSERT INTO ' . dg_prefix() . 'users (email, password_hash, name, phone, provider, picture, verified, support_pin, level, rank_name, joined, status) VALUES (?, NULL, ?, "", "google", ?, 1, ?, 1, "Bronze", ?, "Active")')
            ->execute(array($email, $gName, $picture, $pin, date('Y-m-d')));
        $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE email = ?');
        $st->execute(array($email));
        $row = $st->fetch(PDO::FETCH_ASSOC);
    }
    if ($row['status'] !== 'Active') {
        dg_fail(403, 'এই একাউন্টটি ব্লক করা হয়েছে। সাপোর্টে যোগাযোগ করুন।');
    }
    dg_login_session($row);
    dg_json_out(200, array(
        'ok' => true,
        'account' => dg_profile($row),
        'isAdmin' => $row['role'] === 'admin',
        'me' => dg_me_payload($row),
        'csrf' => dg_csrf_token(),
    ));
}

dg_fail(400, 'Unknown action.');
