<?php
/**
 * DiamondGhor API — convert coins to wallet balance.
 * POST /api/coins-convert.php
 * Rate, floor value and the conversion row are all handled server-side.
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dg_fail(405, 'POST only');
}

$pdo = dg_db();
$user = dg_require_user();
$body = dg_body();
dg_check_csrf($body);
dg_rate_limit('coins', 20, 3600);

$content = dg_content();
$settings = isset($content['coinSettings']) && is_array($content['coinSettings']) ? $content['coinSettings'] : array();
$perTaka = max(1, (int) (isset($settings['coinsPerTaka']) ? $settings['coinsPerTaka'] : 10));
$minCoins = max(1, (int) (isset($settings['minCoins']) ? $settings['minCoins'] : 100));

$pdo->beginTransaction();
try {
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ? FOR UPDATE');
    $st->execute(array((int) $user['id']));
    $fresh = $st->fetch(PDO::FETCH_ASSOC);
    if (!$fresh) {
        throw new Exception('user missing');
    }
    $coins = (int) $fresh['coins'];
    if ($coins < $minCoins) {
        $pdo->rollBack();
        dg_fail(400, 'কমপক্ষে ' . $minCoins . ' কয়েন প্রয়োজন।');
    }
    $value = (int) floor($coins / $perTaka);
    $used = $value * $perTaka;
    if ($used <= 0) {
        $pdo->rollBack();
        dg_fail(400, 'কনভার্ট করার মতো যথেষ্ট কয়েন নেই।');
    }
    $pdo->prepare('UPDATE ' . dg_prefix() . 'users SET coins = coins - ?, balance = balance + ? WHERE id = ?')
        ->execute(array($used, $value, (int) $user['id']));
    $st = $pdo->prepare('INSERT INTO ' . dg_prefix() . 'coin_conversions (user_id, user_email, user_name, coins, amount, status) VALUES (?, ?, ?, ?, ?, "Completed")');
    $st->execute(array((int) $user['id'], $user['email'], $user['name'], $used, $value));
    $convId = (int) $pdo->lastInsertId();
    $pdo->commit();
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    dg_fail(500, 'Conversion failed — একটু পরে আবার চেষ্টা করুন।');
}

dg_bump_rev('ledger');

$st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ?');
$st->execute(array((int) $user['id']));
$fresh = $st->fetch(PDO::FETCH_ASSOC);
$st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'coin_conversions WHERE id = ?');
$st->execute(array($convId));
$convRow = $st->fetch(PDO::FETCH_ASSOC);

dg_json_out(200, array(
    'ok' => true,
    'value' => $value,
    'used' => $used,
    'coins' => $fresh ? (int) $fresh['coins'] : 0,
    'wallet' => $fresh ? (float) $fresh['balance'] : 0,
    'row' => $convRow ? dg_coin_row($convRow) : null,
));
