<?php
/**
 * DiamondGhor API — payment verification step 1: the customer submits the
 * TrxID from the payment screen.
 * POST /api/payment-ref.php  { type: "order"|"deposit", id, method, sender, trxId }
 * TrxIDs are unique across deposits AND orders (checked server-side).
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dg_fail(405, 'POST only');
}

$pdo = dg_db();
$user = dg_require_user();
$body = dg_body();
dg_check_csrf($body);
dg_rate_limit('payref', 30, 3600);

$type = (string) dg_field($body, 'type', 'order');
$id = (string) dg_field($body, 'id', '');
$method = (string) dg_field($body, 'method', 'Gateway');
$sender = preg_replace('/\D/', '', (string) dg_field($body, 'sender', ''));
$trxId = strtoupper(trim((string) dg_field($body, 'trxId', '')));

if (strlen($trxId) < 4) {
    dg_fail(400, 'সঠিক ট্রানজেকশন আইডি দিন।');
}
if (dg_trx_id_used($trxId)) {
    dg_fail(400, 'এই ট্রানজেকশন আইডি আগে ব্যবহার হয়েছে।');
}

$content = dg_content();
$site = isset($content['site']) && is_array($content['site']) ? $content['site'] : array();
$nowStamp = dg_stamp(date('Y-m-d H:i:s'));

if ($type === 'order') {
    $orderId = (int) preg_replace('/\D/', '', $id);
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'orders WHERE id = ?');
    $st->execute(array($orderId));
    $order = $st->fetch(PDO::FETCH_ASSOC);
    if (!$order || (int) $order['user_id'] !== (int) $user['id']) {
        dg_fail(404, 'অর্ডার পাওয়া যায়নি।');
    }
    if ($order['pay_status'] !== 'unpaid') {
        dg_fail(400, 'এই অর্ডারের পেমেন্ট তথ্য আগেই জমা হয়েছে।');
    }
    $ref = json_encode(array('method' => $method, 'sender' => $sender, 'trxId' => $trxId, 'at' => $nowStamp), JSON_UNESCAPED_UNICODE);
    $pdo->prepare('UPDATE ' . dg_prefix() . 'orders SET pay_status = "verifying", payment_ref = ?, message = ? WHERE id = ?')
        ->execute(array($ref, 'পেমেন্ট ভেরিফিকেশনের অপেক্ষায় (TrxID: ' . $trxId . ')। অ্যাডমিন কনফার্ম করলে অর্ডার প্রসেস হবে।', $orderId));
    dg_bump_rev('ledger');
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'orders WHERE id = ?');
    $st->execute(array($orderId));
    $row = $st->fetch(PDO::FETCH_ASSOC);
    // Telegram: payment details of an Instant Pay order just arrived.
    if ($row) {
        dg_telegram_notify($site, dg_msg_order_payment($row, array('method' => $method, 'sender' => $sender, 'trxId' => $trxId), $site));
    }
    dg_json_out(200, array('ok' => true, 'order' => $row ? dg_order_row($row) : null));
}

$depositId = (int) preg_replace('/\D/', '', $id);
$st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'deposits WHERE id = ?');
$st->execute(array($depositId));
$deposit = $st->fetch(PDO::FETCH_ASSOC);
if (!$deposit || (int) $deposit['user_id'] !== (int) $user['id']) {
    dg_fail(404, 'ডিপোজিট রিকোয়েস্ট পাওয়া যায়নি।');
}
if ($deposit['trx_id'] !== '') {
    dg_fail(400, 'এই রিকোয়েস্টে TrxID আগেই জমা হয়েছে।');
}
$pdo->prepare('UPDATE ' . dg_prefix() . 'deposits SET method = ?, sender = ?, trx_id = ? WHERE id = ?')
    ->execute(array($method !== '' ? $method : $deposit['method'], $sender !== '' ? $sender : $deposit['sender'], $trxId, $depositId));
dg_bump_rev('ledger');
$st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'deposits WHERE id = ?');
$st->execute(array($depositId));
$row = $st->fetch(PDO::FETCH_ASSOC);
// An Add Money request just became verifiable — ping the admin.
if ($row && (int) $row['gateway'] === 1) {
    dg_telegram_notify($site, dg_msg_deposit($row, 'usr-' . (int) $user['id'], $site));
}
dg_json_out(200, array('ok' => true, 'deposit' => $row ? dg_deposit_row($row) : null));
