<?php
/**
 * DiamondGhor API — reseller package list (admin only, secrets server-side).
 * POST /api/admin/auto-variations.php  { apiUrl?, apiKey? }
 * When apiUrl/apiKey are omitted, the saved Auto Topup settings are used.
 */

require __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dg_fail(405, 'POST only');
}

$admin = dg_require_admin();
$body = dg_body();
dg_check_csrf($body);
dg_rate_limit('adminauto', 30, 60);

$content = dg_content();
$site = isset($content['site']) && is_array($content['site']) ? $content['site'] : array();
$apiUrl = dg_provider_base((string) dg_field($body, 'apiUrl', isset($site['autoApiUrl']) ? $site['autoApiUrl'] : ''));
$apiKey = (string) dg_field($body, 'apiKey', isset($site['autoApiKey']) ? $site['autoApiKey'] : '');

if ($apiUrl === '' || $apiKey === '') {
    dg_fail(400, 'Missing apiUrl or apiKey.');
}
if (!preg_match('#^https?://#i', $apiUrl)) {
    dg_fail(400, 'Provider URL must start with http:// or https://');
}

$res = dg_provider_post($apiUrl . '/api/variations', array('secret_key' => $apiKey));
if (isset($res['error'])) {
    dg_fail(502, $res['error'] . ' — Provider site e network theke connect kora jayni. Host ta thik ase kina, ar hosting e outbound connection allow ase kina dekhun.');
}

$data = json_decode($res['body'], true);
if (is_array($data) && isset($data['status']) && $data['status'] === 'success') {
    $rows = array();
    if (isset($data['data']) && is_array($data['data'])) {
        $rows = $data['data'];
    } elseif (isset($data[0]) && is_array($data[0])) {
        $rows = $data;
    }
    dg_json_out(200, array('ok' => true, 'packages' => $rows));
}

$failure = dg_provider_failure((int) $res['code'], $res['body'], 'Provider variations request failed.');
dg_fail((int) $res['code'] >= 400 && (int) $res['code'] < 500 ? 400 : 502, $failure['error'] . ($failure['hint'] !== '' ? ' — ' . $failure['hint'] : ''));
