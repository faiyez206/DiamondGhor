<?php
/**
 * DiamondGhor API — manual balance management (server-side money).
 * POST /api/admin/balance.php  { userId | email, type: "Add"|"Deduct", amount, note }
 * Applies the delta in a locked transaction, writes an audit row, notifies
 * the user's Telegram security channel and logs the admin action.
 */

require __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dg_fail(405, 'POST only');
}

$admin = dg_require_admin();
$body = dg_body();
dg_check_csrf($body);
dg_rate_limit('adminbalance', 60, 60);

$pdo = dg_db();
$userId = (string) dg_field($body, 'userId', '');
$email = strtolower((string) dg_field($body, 'email', ''));
$type = (string) dg_field($body, 'type', 'Add') === 'Deduct' ? 'Deduct' : 'Add';
$amount = round((float) dg_field($body, 'amount', 0), 2);
$note = trim((string) dg_field($body, 'note', ''));

if ($amount <= 0) {
    dg_fail(400, 'Enter a valid amount');
}

$userRow = null;
if ($userId !== '') {
    $numeric = (int) preg_replace('/\D/', '', $userId);
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ?');
    $st->execute(array($numeric));
    $userRow = $st->fetch(PDO::FETCH_ASSOC);
} elseif ($email !== '') {
    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE email = ?');
    $st->execute(array($email));
    $userRow = $st->fetch(PDO::FETCH_ASSOC);
}
if (!$userRow) {
    dg_fail(404, 'User not found.');
}

$delta = $type === 'Deduct' ? -$amount : $amount;
$applied = dg_apply_balance($userRow, $delta, $note !== '' ? $note : ('Manual balance ' . strtolower($type)), $admin);
if (!$applied) {
    dg_fail(500, 'Balance update failed.');
}

dg_vip_check($applied, dg_content());
dg_telegram_notify(array(), dg_msg_balance($applied, $type, $amount, $note !== '' ? $note : ('Manual balance ' . strtolower($type))));
dg_admin_log($admin, $type === 'Deduct' ? 'balance.deduct' : 'balance.add', $applied['email'] . ' — ৳' . $amount . ' ' . $type . ($note !== '' ? ' (' . $note . ')' : ''));

dg_json_out(200, array('ok' => true, 'user' => dg_admin_user_row($applied)));
