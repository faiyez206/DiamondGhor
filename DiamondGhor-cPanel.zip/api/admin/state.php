<?php
/**
 * DiamondGhor API — admin panel state.
 * GET /api/admin/state.php?c={contentRev}&a={ledgerRev}
 * Admin session + role required. Returns the FULL content document (with the
 * server-side secrets the public state strips) and the complete ledger.
 */

require __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    dg_fail(405, 'GET only');
}

$admin = dg_require_admin();
dg_rate_limit('adminstate', 120, 60);

$pdo = dg_db();
$content = dg_content();

$ledger = array();

$ledger['orders'] = array();
$st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'orders ORDER BY id DESC LIMIT 500');
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $ledger['orders'][] = dg_order_row($row);
}

$ledger['deposits'] = array();
$st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'deposits ORDER BY id DESC LIMIT 300');
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $ledger['deposits'][] = dg_deposit_row($row);
}

$ledger['spinLogs'] = array();
$st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'spin_logs ORDER BY id DESC LIMIT 200');
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $ledger['spinLogs'][] = dg_spin_log_row($row);
}

$ledger['referrals'] = array();
$st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'referrals ORDER BY id DESC LIMIT 200');
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $ledger['referrals'][] = dg_referral_row($row);
}

$ledger['coinConversions'] = array();
$st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'coin_conversions ORDER BY id DESC LIMIT 200');
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $ledger['coinConversions'][] = dg_coin_row($row);
}

$ledger['users'] = array();
$st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'users ORDER BY id DESC LIMIT 500');
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $ledger['users'][] = dg_admin_user_row($row);
}

$ledger['balanceLogs'] = array();
$st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'balance_logs ORDER BY id DESC LIMIT 200');
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $ledger['balanceLogs'][] = dg_balance_log_row($row);
}

$adminLogs = array();
$st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'admin_logs ORDER BY id DESC LIMIT 50');
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $adminLogs[] = array(
        'id' => (int) $row['id'],
        'admin' => $row['admin_email'],
        'action' => $row['action'],
        'details' => $row['details'],
        'ip' => $row['ip'],
        'date' => dg_stamp($row['created_at']),
    );
}

dg_json_out(200, array(
    'ok' => true,
    'c' => (int) dg_meta_get('rev_c', '0'),
    'a' => (int) dg_meta_get('rev_a', '0'),
    'csrf' => dg_csrf_token(),
    'content' => $content,
    'ledger' => $ledger,
    'adminLogs' => $adminLogs,
));
