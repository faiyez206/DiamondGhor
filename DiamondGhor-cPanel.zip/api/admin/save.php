<?php
/**
 * DiamondGhor API — admin document save + server-side reconciliation.
 * POST /api/admin/save.php  { content?: {...}, ledger?: { orders?, deposits?, users?, referrals?, spinLogs?, coinConversions? } }
 *
 * The admin panel pushes its document (like the old cloud sync did). Content
 * is stored as JSON; ledger rows are reconciled into MySQL — but every money
 * rule is enforced HERE, never in the browser:
 *   • deposit → Approved credits the wallet once (+ audit row + VIP + Telegram)
 *   • order → Failed refunds a paid wallet order once
 *   • order pay_status unpaid → paid fires the "payment verified" notification
 *   • referral → Completed pays the code owner once
 *   • user balance edits become audited balance-log entries
 *   • balanceLogs are server-owned — incoming copies are ignored
 */

require __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dg_fail(405, 'POST only');
}

$admin = dg_require_admin();
$body = dg_body();
dg_check_csrf($body);
dg_rate_limit('adminsave', 240, 60);

$pdo = dg_db();
$site = array();
$content = isset($body['content']) && is_array($body['content']) ? $body['content'] : null;
if ($content) {
    $encoded = json_encode($content, JSON_UNESCAPED_UNICODE);
    if (strlen($encoded) > 2200000) {
        dg_fail(413, 'Content document too large.');
    }
    // Only persist + log when the document actually changed — the admin
    // panel pushes its whole document after every edit burst, and a no-op
    // save would bump rev_c (storefront refresh storm) and spam the log.
    $stored = dg_settings_get('content', null);
    if ($stored === null || md5($stored) !== md5($encoded)) {
        dg_save_content($content);
        dg_admin_log($admin, 'content.save', 'Content updated (' . strlen($encoded) . ' bytes)');
    }
    $site = isset($content['site']) && is_array($content['site']) ? $content['site'] : array();
} else {
    $full = dg_content();
    $site = isset($full['site']) && is_array($full['site']) ? $full['site'] : array();
}

$ledger = isset($body['ledger']) && is_array($body['ledger']) ? $body['ledger'] : null;
$changedLedger = false;
$fixed = array();

function dg_bool_val($value) {
    if (is_bool($value)) return $value ? 1 : 0;
    return (int) $value ? 1 : 0;
}

if ($ledger) {
    // ------------------------------------------------ orders
    if (isset($ledger['orders']) && is_array($ledger['orders'])) {
        $incoming = array();
        foreach ($ledger['orders'] as $row) {
            if (is_array($row) && isset($row['id']) && is_numeric($row['id'])) {
                $incoming[(int) $row['id']] = $row;
            }
        }
        $dbRows = array();
        $st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'orders');
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $dbRows[(int) $row['id']] = $row;
        }
        foreach ($incoming as $id => $ui) {
            if (!isset($dbRows[$id])) {
                continue;
            }
            $old = $dbRows[$id];
            $sets = array();
            $params = array();
            $fieldMap = array(
                'status' => 'status',
                'playerName' => 'player_name',
                'message' => 'message',
                'payStatus' => 'pay_status',
                'autoStatus' => 'auto_status',
                'providerOrderid' => 'provider_orderid',
                'autoNote' => 'auto_note',
            );
            foreach ($fieldMap as $uiKey => $col) {
                if (array_key_exists($uiKey, $ui) && (string) $ui[$uiKey] !== (string) $old[$col]) {
                    $sets[] = $col . ' = ?';
                    $params[] = $ui[$uiKey] === null ? null : (string) $ui[$uiKey];
                }
            }
            if (isset($ui['price']) && round((float) $ui['price'], 2) !== round((float) $old['price'], 2)) {
                $sets[] = 'price = ?';
                $params[] = round((float) $ui['price'], 2);
            }
            if (isset($ui['walletPaid']) && dg_bool_val($ui['walletPaid']) !== (int) $old['wallet_paid']) {
                $sets[] = 'wallet_paid = ?';
                $params[] = dg_bool_val($ui['walletPaid']);
            }
            if (isset($ui['gatewayPay']) && dg_bool_val($ui['gatewayPay']) !== (int) $old['gateway_pay']) {
                $sets[] = 'gateway_pay = ?';
                $params[] = dg_bool_val($ui['gatewayPay']);
            }
            if (isset($ui['paymentRef']) && is_array($ui['paymentRef'])) {
                $newRef = json_encode($ui['paymentRef'], JSON_UNESCAPED_UNICODE);
                $oldRef = $old['payment_ref'] ? json_encode(json_decode($old['payment_ref'], true), JSON_UNESCAPED_UNICODE) : '';
                if ($newRef !== $oldRef) {
                    $sets[] = 'payment_ref = ?';
                    $params[] = $newRef;
                }
            }
            if ($sets) {
                $params[] = $id;
                $pdo->prepare('UPDATE ' . dg_prefix() . 'orders SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);
                $changedLedger = true;
            }
            // Side effects (read the fresh row).
            $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'orders WHERE id = ?');
            $st->execute(array($id));
            $fresh = $st->fetch(PDO::FETCH_ASSOC);
            if (!$fresh) {
                continue;
            }
            if ($old['pay_status'] === 'unpaid' && $fresh['pay_status'] === 'paid') {
                dg_telegram_notify($site, dg_msg_payment_verified($fresh, $site));
                dg_admin_log($admin, 'order.payment_verified', 'Order #' . $id . ' payment verified (TrxID ' . (isset($ui['paymentRef']['trxId']) ? $ui['paymentRef']['trxId'] : '—') . ')');
            }
            if ($fresh['status'] === 'Failed' && (int) $fresh['wallet_paid'] === 1 && (int) $fresh['refunded'] === 0) {
                dg_refund_failed_order($fresh, 'অ্যাডমিন অর্ডারটি বাতিল করেছেন।');
                dg_admin_log($admin, 'order.refund', 'Order #' . $id . ' marked Failed — ৳' . $fresh['price'] . ' refunded to wallet');
                $changedLedger = true;
            }
        }
        // Delete-on-omit (same semantics as the old cloud sync) — but never
        // when the incoming list is empty, so a broken sync cannot wipe data.
        if (count($incoming) > 0) {
            foreach ($dbRows as $id => $row) {
                if (!isset($incoming[$id])) {
                    $pdo->prepare('DELETE FROM ' . dg_prefix() . 'orders WHERE id = ?')->execute(array($id));
                    dg_admin_log($admin, 'order.delete', 'Order #' . $id . ' deleted');
                    $changedLedger = true;
                }
            }
        }
    }

    // ------------------------------------------------ users
    if (isset($ledger['users']) && is_array($ledger['users'])) {
        $incoming = array();
        foreach ($ledger['users'] as $row) {
            if (is_array($row) && isset($row['id'])) {
                $incoming[(string) $row['id']] = $row;
            }
        }
        $dbRows = array();
        $st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'users');
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $dbRows[(int) $row['id']] = $row;
        }
        foreach ($incoming as $uiId => $ui) {
            $numeric = (int) preg_replace('/\D/', '', (string) $uiId);
            if ($numeric > 0 && isset($dbRows[$numeric])) {
                $old = $dbRows[$numeric];
                $sets = array();
                $params = array();
                foreach (array('name' => 'name', 'phone' => 'phone') as $uiKey => $col) {
                    if (array_key_exists($uiKey, $ui) && (string) $ui[$uiKey] !== (string) $old[$col]) {
                        $sets[] = $col . ' = ?';
                        $params[] = (string) $ui[$uiKey];
                    }
                }
                if (isset($ui['role']) && (($ui['role'] === 'ADMIN' ? 'admin' : 'user') !== $old['role'])) {
                    // Never demote the last admin.
                    if ($old['role'] === 'admin' && $ui['role'] !== 'ADMIN') {
                        $cnt = (int) $pdo->query('SELECT COUNT(*) FROM ' . dg_prefix() . "users WHERE role = 'admin'")->fetchColumn();
                        if ($cnt <= 1) {
                            $fixed['users'][$uiId] = array('role' => 'ADMIN');
                        } else {
                            $sets[] = 'role = "user"';
                        }
                    } else {
                        $sets[] = 'role = ' . ($ui['role'] === 'ADMIN' ? '"admin"' : '"user"');
                    }
                }
                if (isset($ui['status']) && (string) $ui['status'] !== (string) $old['status']) {
                    $sets[] = 'status = ?';
                    $params[] = (string) $ui['status'] === 'Blocked' ? 'Blocked' : 'Active';
                }
                foreach (array('premium', 'verified', 'reseller') as $flag) {
                    if (isset($ui[$flag]) && dg_bool_val($ui[$flag]) !== (int) $old[$flag]) {
                        $sets[] = $flag . ' = ?';
                        $params[] = dg_bool_val($ui[$flag]);
                    }
                }
                if (isset($ui['email'])) {
                    $email = strtolower(trim((string) $ui['email']));
                    if ($email !== '' && $email !== (string) $old['email']) {
                        $chk = $pdo->prepare('SELECT id FROM ' . dg_prefix() . 'users WHERE email = ? AND id != ?');
                        $chk->execute(array($email, $numeric));
                        if ($chk->fetch()) {
                            $fixed['users'][$uiId] = isset($fixed['users'][$uiId]) ? array_merge($fixed['users'][$uiId], array('email' => $old['email'])) : array('email' => $old['email']);
                        } else {
                            $sets[] = 'email = ?';
                            $params[] = $email;
                        }
                    }
                }
                if ($sets) {
                    $params[] = $numeric;
                    $pdo->prepare('UPDATE ' . dg_prefix() . 'users SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);
                    $changedLedger = true;
                }
                // Balance edits through the Users table become audited deltas.
                if (isset($ui['balance'])) {
                    $newBalance = round((float) $ui['balance'], 2);
                    if ($newBalance !== round((float) $old['balance'], 2)) {
                        $delta = round($newBalance - (float) $old['balance'], 2);
                        $applied = dg_apply_balance($old, $delta, 'Admin panel user edit', $admin);
                        if ($applied) {
                            dg_telegram_notify($site, dg_msg_balance($applied, $delta >= 0 ? 'Add' : 'Deduct', abs($delta), 'Admin panel user edit'));
                            dg_admin_log($admin, 'user.balance', $old['email'] . ' balance ' . ($delta >= 0 ? '+' : '') . $delta . ' (Users page edit)');
                            $changedLedger = true;
                        }
                    }
                }
            } else {
                // New user created from the admin panel (no password — the
                // account can sign in with Google or after a password is set).
                $email = strtolower(trim((string) (isset($ui['email']) ? $ui['email'] : '')));
                if ($email !== '') {
                    $chk = $pdo->prepare('SELECT id FROM ' . dg_prefix() . 'users WHERE email = ?');
                    $chk->execute(array($email));
                    if ($chk->fetch()) {
                        $fixed['users'][$uiId] = array('duplicate' => true);
                        continue;
                    }
                    $pin = str_pad((string) random_int(0, 9999), 4, '0', STR_PAD_LEFT);
                    $role = (isset($ui['role']) && $ui['role'] === 'ADMIN') ? 'admin' : 'user';
                    $status = (isset($ui['status']) && $ui['status'] === 'Blocked') ? 'Blocked' : 'Active';
                    $balance = isset($ui['balance']) ? round((float) $ui['balance'], 2) : 0;
                    $name = (string) (isset($ui['name']) ? $ui['name'] : '');
                    $phone = (string) (isset($ui['phone']) ? $ui['phone'] : '');
                    $joined = isset($ui['joined']) && $ui['joined'] ? date('Y-m-d', strtotime((string) $ui['joined'])) : date('Y-m-d');
                    $st = $pdo->prepare('INSERT INTO ' . dg_prefix() . 'users (email, password_hash, name, phone, provider, role, balance, premium, verified, reseller, support_pin, joined, status) VALUES (?, NULL, ?, ?, "admin-created", ?, ?, ?, ?, ?, ?, ?, ?)');
                    $st->execute(array(
                        $email,
                        $name,
                        $phone,
                        $role,
                        $balance,
                        dg_bool_val(isset($ui['premium']) ? $ui['premium'] : false),
                        dg_bool_val(isset($ui['verified']) ? $ui['verified'] : true),
                        dg_bool_val(isset($ui['reseller']) ? $ui['reseller'] : false),
                        $pin,
                        $joined,
                        $status,
                    ));
                    $newId = (int) $pdo->lastInsertId();
                    if ($balance > 0) {
                        $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ?');
                        $st->execute(array($newId));
                        $fresh = $st->fetch(PDO::FETCH_ASSOC);
                        if ($fresh) {
                            dg_balance_log($fresh, 'Add', $balance, $balance, 'Admin created user with balance', $admin);
                        }
                    }
                    $fixed['users'][$uiId] = array('id' => 'usr-' . $newId);
                    dg_admin_log($admin, 'user.create', 'User created: ' . $email);
                    $changedLedger = true;
                }
            }
        }
        if (count($incoming) > 0) {
            $adminCount = (int) $pdo->query('SELECT COUNT(*) FROM ' . dg_prefix() . "users WHERE role = 'admin'")->fetchColumn();
            foreach ($dbRows as $id => $row) {
                $uiId = 'usr-' . $id;
                if (isset($incoming[$uiId])) {
                    continue;
                }
                if ((int) $id === (int) $admin['id']) {
                    $fixed['users'][$uiId] = array('protected' => 'self');
                    continue;
                }
                if ($row['role'] === 'admin' && $adminCount <= 1) {
                    $fixed['users'][$uiId] = array('protected' => 'last-admin');
                    continue;
                }
                if ($row['role'] === 'admin') {
                    $adminCount -= 1;
                }
                $pdo->prepare('DELETE FROM ' . dg_prefix() . 'users WHERE id = ?')->execute(array($id));
                dg_admin_log($admin, 'user.delete', 'User deleted: ' . $row['email']);
                $changedLedger = true;
            }
        }
    }

    // ------------------------------------------------ deposits
    if (isset($ledger['deposits']) && is_array($ledger['deposits'])) {
        $incoming = array();
        foreach ($ledger['deposits'] as $row) {
            if (is_array($row) && isset($row['id'])) {
                $numeric = (int) preg_replace('/\D/', '', (string) $row['id']);
                if ($numeric > 0) {
                    $incoming[$numeric] = $row;
                }
            }
        }
        $dbRows = array();
        $st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'deposits');
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $dbRows[(int) $row['id']] = $row;
        }
        foreach ($incoming as $id => $ui) {
            if (!isset($dbRows[$id])) {
                continue;
            }
            $old = $dbRows[$id];
            $sets = array();
            $params = array();
            foreach (array('status' => 'status', 'method' => 'method', 'sender' => 'sender', 'trxId' => 'trx_id') as $uiKey => $col) {
                if (array_key_exists($uiKey, $ui) && (string) $ui[$uiKey] !== (string) $old[$col]) {
                    $sets[] = $col . ' = ?';
                    $params[] = (string) $ui[$uiKey];
                }
            }
            if ($sets) {
                $params[] = $id;
                $pdo->prepare('UPDATE ' . dg_prefix() . 'deposits SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);
                $changedLedger = true;
            }
            $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'deposits WHERE id = ?');
            $st->execute(array($id));
            $fresh = $st->fetch(PDO::FETCH_ASSOC);
            if (!$fresh) {
                continue;
            }
            // Approve = server-side credit, exactly once.
            if ($old['status'] !== 'Approved' && $fresh['status'] === 'Approved' && (int) $fresh['credited'] === 0) {
                $userRow = null;
                if ($fresh['user_id']) {
                    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ?');
                    $st->execute(array((int) $fresh['user_id']));
                    $userRow = $st->fetch(PDO::FETCH_ASSOC);
                }
                if ($userRow) {
                    dg_apply_balance($userRow, (float) $fresh['amount'], 'Add Money approved (dp-' . $id . ')', $admin);
                    $pdo->prepare('UPDATE ' . dg_prefix() . 'deposits SET credited = 1 WHERE id = ?')->execute(array($id));
                    dg_vip_check($userRow, dg_content());
                    dg_telegram_notify($site, implode("\n", array(
                        '✅ ADD MONEY APPROVED!',
                        '',
                        '━━━━━━━━━━━━━━━',
                        '👤 User: ' . $fresh['user_name'],
                        '💵 Amount: ৳' . round((float) $fresh['amount'], 2),
                        '📅 Date: ' . dg_dmy(),
                        '━━━━━━━━━━━━━━━',
                    )));
                    dg_admin_log($admin, 'deposit.approve', 'dp-' . $id . ' approved — ৳' . round((float) $fresh['amount'], 2) . ' credited to ' . $fresh['user_email']);
                    $changedLedger = true;
                }
            }
        }
        if (count($incoming) > 0) {
            foreach ($dbRows as $id => $row) {
                if (!isset($incoming[$id])) {
                    $pdo->prepare('DELETE FROM ' . dg_prefix() . 'deposits WHERE id = ?')->execute(array($id));
                    dg_admin_log($admin, 'deposit.delete', 'dp-' . $id . ' deleted');
                    $changedLedger = true;
                }
            }
        }
    }

    // ------------------------------------------------ referrals
    if (isset($ledger['referrals']) && is_array($ledger['referrals'])) {
        $incoming = array();
        foreach ($ledger['referrals'] as $row) {
            if (is_array($row) && isset($row['id'])) {
                $numeric = (int) preg_replace('/\D/', '', (string) $row['id']);
                if ($numeric > 0) {
                    $incoming[$numeric] = $row;
                }
            }
        }
        $dbRows = array();
        $st = $pdo->query('SELECT * FROM ' . dg_prefix() . 'referrals');
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $dbRows[(int) $row['id']] = $row;
        }
        foreach ($incoming as $id => $ui) {
            if (!isset($dbRows[$id])) {
                continue;
            }
            $old = $dbRows[$id];
            $sets = array();
            $params = array();
            foreach (array('status' => 'status', 'code' => 'code', 'referred' => 'referred_email') as $uiKey => $col) {
                if (array_key_exists($uiKey, $ui) && (string) $ui[$uiKey] !== (string) $old[$col]) {
                    $sets[] = $col . ' = ?';
                    $params[] = (string) $ui[$uiKey];
                }
            }
            if (isset($ui['reward']) && round((float) $ui['reward'], 2) !== round((float) $old['reward'], 2)) {
                $sets[] = 'reward = ?';
                $params[] = round((float) $ui['reward'], 2);
            }
            if ($sets) {
                $params[] = $id;
                $pdo->prepare('UPDATE ' . dg_prefix() . 'referrals SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);
                $changedLedger = true;
            }
            $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'referrals WHERE id = ?');
            $st->execute(array($id));
            $fresh = $st->fetch(PDO::FETCH_ASSOC);
            if (!$fresh) {
                continue;
            }
            // Approval pays the referral code owner, server-side, once.
            if ($old['status'] !== 'Completed' && $fresh['status'] === 'Completed' && (int) $fresh['paid'] === 0 && (float) $fresh['reward'] > 0) {
                $referrer = null;
                if ($fresh['referrer_user_id']) {
                    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE id = ?');
                    $st->execute(array((int) $fresh['referrer_user_id']));
                    $referrer = $st->fetch(PDO::FETCH_ASSOC);
                }
                if (!$referrer && preg_match('/DG(\d{4})$/i', (string) $fresh['code'], $m)) {
                    $st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'users WHERE support_pin = ? LIMIT 1');
                    $st->execute(array($m[1]));
                    $referrer = $st->fetch(PDO::FETCH_ASSOC);
                }
                if ($referrer) {
                    $applied = dg_apply_balance($referrer, (float) $fresh['reward'], 'Referral reward — ' . $fresh['referred_email'], $admin);
                    if ($applied) {
                        $pdo->prepare('UPDATE ' . dg_prefix() . 'referrals SET paid = 1 WHERE id = ?')->execute(array($id));
                        dg_telegram_notify($site, dg_msg_balance($applied, 'Add', (float) $fresh['reward'], 'Referral reward — ' . $fresh['referred_email']));
                        dg_admin_log($admin, 'referral.approve', 'rf-' . $id . ' completed — ৳' . round((float) $fresh['reward'], 2) . ' paid to ' . $referrer['email']);
                        $changedLedger = true;
                    }
                }
            }
        }
        if (count($incoming) > 0) {
            foreach ($dbRows as $id => $row) {
                if (!isset($incoming[$id])) {
                    $pdo->prepare('DELETE FROM ' . dg_prefix() . 'referrals WHERE id = ?')->execute(array($id));
                    $changedLedger = true;
                }
            }
        }
    }

    // ------------------------------------------------ spin logs
    if (isset($ledger['spinLogs']) && is_array($ledger['spinLogs'])) {
        $incoming = array();
        foreach ($ledger['spinLogs'] as $row) {
            if (is_array($row) && isset($row['id'])) {
                $numeric = (int) preg_replace('/\D/', '', (string) $row['id']);
                if ($numeric > 0) {
                    $incoming[$numeric] = $row;
                }
            }
        }
        $dbRows = array();
        $st = $pdo->query('SELECT id, status FROM ' . dg_prefix() . 'spin_logs');
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $dbRows[(int) $row['id']] = $row;
        }
        foreach ($incoming as $id => $ui) {
            if (!isset($dbRows[$id])) {
                continue;
            }
            $newStatus = (string) (isset($ui['status']) ? $ui['status'] : $dbRows[$id]['status']);
            if ($newStatus !== $dbRows[$id]['status']) {
                $pdo->prepare('UPDATE ' . dg_prefix() . 'spin_logs SET status = ? WHERE id = ?')->execute(array($newStatus, $id));
                $changedLedger = true;
            }
        }
        if (count($incoming) > 0) {
            foreach ($dbRows as $id => $row) {
                if (!isset($incoming[$id])) {
                    $pdo->prepare('DELETE FROM ' . dg_prefix() . 'spin_logs WHERE id = ?')->execute(array($id));
                    $changedLedger = true;
                }
            }
        }
    }

    // ------------------------------------------------ coin conversions
    if (isset($ledger['coinConversions']) && is_array($ledger['coinConversions'])) {
        $incoming = array();
        foreach ($ledger['coinConversions'] as $row) {
            if (is_array($row) && isset($row['id'])) {
                $numeric = (int) preg_replace('/\D/', '', (string) $row['id']);
                if ($numeric > 0) {
                    $incoming[$numeric] = $row;
                }
            }
        }
        $dbRows = array();
        $st = $pdo->query('SELECT id, status FROM ' . dg_prefix() . 'coin_conversions');
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $dbRows[(int) $row['id']] = $row;
        }
        foreach ($incoming as $id => $ui) {
            if (!isset($dbRows[$id])) {
                continue;
            }
            $newStatus = (string) (isset($ui['status']) ? $ui['status'] : $dbRows[$id]['status']);
            if ($newStatus !== $dbRows[$id]['status']) {
                $pdo->prepare('UPDATE ' . dg_prefix() . 'coin_conversions SET status = ? WHERE id = ?')->execute(array($newStatus, $id));
                $changedLedger = true;
            }
        }
        if (count($incoming) > 0) {
            foreach ($dbRows as $id => $row) {
                if (!isset($incoming[$id])) {
                    $pdo->prepare('DELETE FROM ' . dg_prefix() . 'coin_conversions WHERE id = ?')->execute(array($id));
                    $changedLedger = true;
                }
            }
        }
    }

    // balanceLogs: server-owned — incoming copies are intentionally ignored.
}

if ($changedLedger) {
    dg_bump_rev('ledger');
}

dg_json_out(200, array(
    'ok' => true,
    'fixed' => $fixed,
    'c' => (int) dg_meta_get('rev_c', '0'),
    'a' => (int) dg_meta_get('rev_a', '0'),
));
