<?php
/**
 * DiamondGhor API — send/retry an order at the reseller provider (admin).
 * POST /api/admin/auto-place-order.php  { orderId }
 * Uses the server-side Auto Topup settings; updates the order row and the
 * per-order webhook key so the provider can report the final status.
 */

require __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dg_fail(405, 'POST only');
}

$admin = dg_require_admin();
$body = dg_body();
dg_check_csrf($body);
dg_rate_limit('adminauto', 30, 60);

$orderId = (int) preg_replace('/\D/', '', (string) dg_field($body, 'orderId', ''));
if ($orderId <= 0) {
    dg_fail(400, 'Missing orderId.');
}

$st = dg_db()->prepare('SELECT * FROM ' . dg_prefix() . 'orders WHERE id = ?');
$st->execute(array($orderId));
$order = $st->fetch(PDO::FETCH_ASSOC);
if (!$order) {
    dg_fail(404, 'Order not found.');
}
if ((string) $order['api_package_id'] === '') {
    dg_fail(400, 'This order has no provider package ID (Variations e Auto topup package ID boshan).');
}

$result = dg_forward_to_provider($order, dg_content(), false);
if (isset($result['skipped'])) {
    dg_fail(400, 'Auto Topup is not configured — Admin → Settings → Auto Topup API.');
}
if (!is_array($result) || empty($result['ok'])) {
    $error = is_array($result) && isset($result['error']) ? $result['error'] : 'Provider e pathano jayni.';
    $hint = is_array($result) && isset($result['hint']) ? $result['hint'] : '';
    dg_fail(502, $hint !== '' ? $error . ' — ' . $hint : $error);
}

dg_admin_log($admin, 'order.send_provider', 'Order #' . $orderId . ' sent to provider' . (isset($result['data']['orderid']) && $result['data']['orderid'] !== '' ? ' (provider order ' . $result['data']['orderid'] . ')' : ''));
dg_json_out(200, array('ok' => true, 'data' => isset($result['data']) ? $result['data'] : null));
