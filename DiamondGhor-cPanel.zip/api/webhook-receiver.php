<?php
/**
 * DiamondGhor API — auto-topup webhook receiver (called by the provider).
 * POST /api/webhook-receiver.php?key={per-order key}
 * Body: { orderid: "DG-554", status: "success"|"error", content: "..." }
 * The ?key= must match the key generated with the order (stored in MySQL).
 * Final states complete the order; errors refund wallet orders exactly once.
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dg_fail(405, 'POST only');
}

$pdo = dg_db();
$key = isset($_GET['key']) ? (string) $_GET['key'] : '';
$body = dg_body();
$orderid = (string) dg_field($body, 'orderid', '');
$status = strtolower((string) dg_field($body, 'status', ''));
$contentText = (string) dg_field($body, 'content', '');

if ($orderid === '' || $key === '') {
    dg_fail(400, 'Missing orderid or key.');
}

$st = $pdo->prepare('SELECT * FROM ' . dg_prefix() . 'orders WHERE client_order_id = ? LIMIT 1');
$st->execute(array($orderid));
$order = $st->fetch(PDO::FETCH_ASSOC);
if (!$order) {
    dg_fail(404, 'Unknown order.');
}
if ($order['webhook_key'] === '' || !hash_equals((string) $order['webhook_key'], $key)) {
    dg_fail(403, 'Invalid webhook key.');
}

// Record the provider's note, then apply the final status.
if ($status === 'success' || $status === 'error') {
    if ($contentText !== '') {
        $pdo->prepare('UPDATE ' . dg_prefix() . 'orders SET auto_note = ? WHERE id = ?')
            ->execute(array($contentText, (int) $order['id']));
        $order['auto_note'] = $contentText;
    }
    dg_apply_provider_status($order, $status, dg_content());
}

dg_json_out(200, array('ok' => true));
