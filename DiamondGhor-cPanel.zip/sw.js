/* DiamondGhor service worker — makes the installed PWA open instantly and
   work offline. Strategy:
   - navigations (HTML): network-first, cached app shell as offline fallback
   - hashed build assets (/assets/…): cache-first (they never change)
   - other same-origin statics (icons, manifest): stale-while-revalidate
   - /api/* and cross-origin (Firebase, fonts, payment…): always network
   The admin can turn the whole PWA off from Settings → PWA App (the app
   then unregisters this worker). */
const CACHE = 'dg-shell-v1'

const SHELL = [
  '/',
  '/manifest.webmanifest',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
]

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((cache) => cache.addAll(SHELL))
      .catch(() => null) // never block install on a missing optional file
      .then(() => self.skipWaiting()),
  )
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  )
})

self.addEventListener('fetch', (event) => {
  const request = event.request
  if (request.method !== 'GET') return

  let url
  try {
    url = new URL(request.url)
  } catch {
    return
  }
  // Only handle same-origin http(s) requests — Firebase REST, fonts, payment
  // gateways and the reseller API always go straight to the network.
  if (url.origin !== self.location.origin) return
  if (url.pathname.startsWith('/api/')) return

  // Page navigations: try the network first so users always get the freshest
  // build; fall back to the cached shell when offline.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response && response.ok) {
            const clone = response.clone()
            caches.open(CACHE).then((cache) => cache.put('/', clone)).catch(() => null)
          }
          return response
        })
        .catch(() =>
          caches
            .match('/', { ignoreSearch: true })
            .then((cached) => cached || caches.match('/index.html'))
            .then((cached) => cached || new Response('Offline', { status: 503 })),
        ),
    )
    return
  }

  // Hashed build assets are immutable — cache-first is safe and instant.
  if (url.pathname.startsWith('/assets/')) {
    event.respondWith(
      caches.match(request).then(
        (cached) =>
          cached ||
          fetch(request).then((response) => {
            if (response && response.ok) {
              const clone = response.clone()
              caches.open(CACHE).then((cache) => cache.put(request, clone)).catch(() => null)
            }
            return response
          }),
      ),
    )
    return
  }

  // Everything else same-origin (icons, manifest, sw.js itself):
  // serve from cache and refresh in the background.
  event.respondWith(
    caches.match(request).then((cached) => {
      const refresh = fetch(request)
        .then((response) => {
          if (response && response.ok) {
            const clone = response.clone()
            caches.open(CACHE).then((cache) => cache.put(request, clone)).catch(() => null)
          }
          return response
        })
        .catch(() => cached)
      return cached || refresh
    }),
  )
})
